import pl.ispinalokalnie.kindlewifi.RemoteFiles;
import com.jcraft.jsch.*;
import java.nio.file.*;
import java.util.*;
public class RemoteFilesTest {
 interface Throwing {void run() throws Exception;}
 static void rejected(Throwing task)throws Exception{try{task.run();}catch(Exception e){return;}throw new AssertionError("Unsafe operation accepted");}
 public static void main(String[] args)throws Exception{
  Path work=Paths.get(args[0]).toAbsolutePath();Path docs=Files.createTempDirectory(work,"documents-");Path books=Files.createTempDirectory(work,"Books-");
  JSch ssh=new JSch();ssh.addIdentity(work.resolve("server/client").toString());
  Session session=ssh.getSession(System.getProperty("user.name"),"127.0.0.1",22222);session.setConfig("StrictHostKeyChecking","no");session.connect(5000);
  ChannelSftp c=(ChannelSftp)session.openChannel("sftp");c.connect();
  try{
   RemoteFiles f=new RemoteFiles(c,docs.toString(),books.toString());
   byte[] data="Historia Ispiny".getBytes("UTF-8");
   Path a=docs.resolve("Ispina [1].epub");Files.write(a,data);
   Files.write(docs.resolve("keep.pdf"),data);Files.write(docs.resolve("settings.lua"),data);
   Files.createDirectory(docs.resolve("Ispina [1].sdr"));
   if(f.list(docs.toString()).size()!=2)throw new AssertionError("Visible files filter");
   f.mkdir(docs.toString(),"Polskie książki");
   f.rename(a.toString(),"Życie Ispiny.epub");
   Path renamed=docs.resolve("Życie Ispiny.epub");
   if(Files.exists(a)||!Arrays.equals(data,Files.readAllBytes(renamed)))throw new AssertionError("Rename bytes");
   System.out.println("PASS: list filters book files; folder creation; Unicode rename preserves bytes");
   Files.write(docs.resolve("taken.epub"),"existing".getBytes("UTF-8"));
   rejected(()->f.rename(renamed.toString(),"taken.epub"));
   if(!new String(Files.readAllBytes(docs.resolve("taken.epub")),"UTF-8").equals("existing"))throw new AssertionError("Overwritten");
   rejected(()->f.rename(renamed.toString(),"wrong.pdf"));
   rejected(()->f.rename(renamed.toString(),"../escape.epub"));
   rejected(()->f.mkdir(docs.toString(),"../escape"));
   rejected(()->f.delete(docs.resolve("settings.lua").toString()));
   rejected(()->f.delete(docs.resolve("Polskie książki").toString()));
   System.out.println("PASS: duplicate, format change, traversal, non-book deletion and folder deletion rejected");
   f.move(renamed.toString(),books.toString());
   Path moved=books.resolve(renamed.getFileName());
   if(Files.exists(renamed)||!Arrays.equals(data,Files.readAllBytes(moved)))throw new AssertionError("Move");
   f.move(moved.toString(),docs.resolve("Polskie książki").toString());
   Path finalFile=docs.resolve("Polskie książki").resolve(renamed.getFileName());
   f.delete(finalFile.toString());if(Files.exists(finalFile))throw new AssertionError("Delete");
   rejected(()->f.delete(finalFile.toString()));
   System.out.println("PASS: move across roots and nested folder; delete checked on disk; missing file fails");
   Path outside=Files.createTempDirectory(work,"outside-");Files.write(outside.resolve("secret.epub"),data);
   Files.createSymbolicLink(docs.resolve("shortcut"),outside);
   Files.createSymbolicLink(docs.resolve("link.epub"),outside.resolve("secret.epub"));
   rejected(()->f.list(docs.resolve("shortcut").toString()));
   rejected(()->f.delete(docs.resolve("link.epub").toString()));
   rejected(()->f.move(docs.resolve("keep.pdf").toString(),outside.toString()));
   if(!Files.exists(outside.resolve("secret.epub")))throw new AssertionError("Outside file lost");
   System.out.println("PASS: links and paths outside book roots rejected; unrelated files preserved");
   System.out.println("ALL FILE MANAGER TESTS PASSED");
  }finally{c.disconnect();session.disconnect();}
 }
}
