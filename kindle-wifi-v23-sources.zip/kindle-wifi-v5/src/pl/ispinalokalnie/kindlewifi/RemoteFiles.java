package pl.ispinalokalnie.kindlewifi;

import com.jcraft.jsch.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** All mutation paths are confined to book directories, never system folders. */
public final class RemoteFiles {
    private final ChannelSftp channel;
    private final String[] roots;
    public static final class Entry {
        public final String name, path;
        public final boolean directory;
        public final long size;
        public Entry(String n, String p, boolean d, long s) { name=n; path=p; directory=d; size=s; }
    }
    public RemoteFiles(ChannelSftp c, String... r) { channel=c; roots=r; }
    private String literal(String p) { return VerifiedTransfer.literal(p); }
    private String root(String path) throws IOException {
        if (path.contains("/../") || path.endsWith("/..") || path.contains("/./") || path.contains("//"))
            throw new IOException("Nieprawidłowa ścieżka folderu.");
        for (String r : roots) if (path.equals(r) || path.startsWith(r + "/")) return r;
        throw new IOException("Dostęp jest ograniczony do folderów z książkami.");
    }
    public void directory(String path) throws Exception {
        String r = root(path);
        String current = r;
        if (channel.lstat(literal(current)).isLink() || !channel.stat(literal(current)).isDir())
            throw new IOException("Folder książek nie jest zwykłym katalogiem.");
        String realRoot = channel.realpath(r);
        if (!realRoot.equals(r)) throw new IOException("Folder książek prowadzi poza dozwoloną lokalizację.");
        String tail = path.substring(r.length());
        for (String part : tail.split("/")) if (!part.isEmpty()) {
            if (part.equals(".") || part.equals("..") || part.startsWith(".") || part.endsWith(".sdr"))
                throw new IOException("Ten folder nie służy do przechowywania książek.");
            current += "/" + part;
            SftpATTRS a = channel.lstat(literal(current));
            if (a.isLink() || !a.isDir()) throw new IOException("Nie można otworzyć tego folderu.");
        }
    }
    private SftpATTRS file(String path) throws Exception {
        root(path);
        directory(path.substring(0,path.lastIndexOf('/')));
        SftpATTRS a=channel.lstat(literal(path));
        if (a.isLink() || !a.isReg() || !book(path.substring(path.lastIndexOf('/')+1)))
            throw new IOException("Wybierz zwykły plik książki.");
        return a;
    }
    public static boolean book(String name) {
        String lower=name.toLowerCase(Locale.ROOT);
        return !name.startsWith(".") && lower.matches(".*\\.(epub|pdf|mobi|azw|azw3|fb2|txt|djvu|cbz)$");
    }
    public static String validName(String name) throws IOException {
        if (name == null || name.trim().isEmpty() || !name.equals(name.trim()) || name.startsWith(".")
                || name.endsWith(".") || name.matches(".*[\\\\/:*?\"<>|\\p{Cntrl}].*")
                || name.getBytes(StandardCharsets.UTF_8).length>220)
            throw new IOException("Podaj nazwę bez ukośników i znaków specjalnych (maks. 220 bajtów). ");
        return name;
    }
    private void absent(String path) throws Exception {
        try { channel.lstat(literal(path)); }
        catch(SftpException e) { if(e.id==ChannelSftp.SSH_FX_NO_SUCH_FILE) return; throw e; }
        throw new IOException("Plik lub folder o tej nazwie już istnieje. Wybierz inną nazwę.");
    }
    public List<Entry> list(String path) throws Exception {
        directory(path);
        List<Entry> result=new ArrayList<>();
        for(ChannelSftp.LsEntry e: channel.ls(literal(path))) {
            String name=e.getFilename(); SftpATTRS a=e.getAttrs();
            if(name.startsWith(".") || name.endsWith(".sdr") || a.isLink()) continue;
            if(a.isDir() || (a.isReg() && book(name))) result.add(new Entry(name,path+"/"+name,a.isDir(),a.getSize()));
        }
        Collections.sort(result,(a,b)->a.directory!=b.directory?(a.directory?-1:1):a.name.compareToIgnoreCase(b.name));
        return result;
    }
    public void mkdir(String parent,String name) throws Exception {
        directory(parent); validName(name);
        if(name.endsWith(".sdr")) throw new IOException("Wybierz inną nazwę folderu.");
        String path=parent+"/"+name; absent(path); channel.mkdir(path); directory(path);
    }
    public void rename(String path,String name) throws Exception {
        validName(name);
        String old=path.substring(path.lastIndexOf('/')+1);
        String ext=old.substring(old.lastIndexOf('.'));
        if(!name.endsWith(ext)) throw new IOException("Końcówka formatu książki musi pozostać taka sama.");
        moveTo(path,path.substring(0,path.lastIndexOf('/'))+"/"+name);
    }
    public void move(String path,String destination) throws Exception {
        directory(destination);
        moveTo(path,destination+path.substring(path.lastIndexOf('/')));
    }
    private void moveTo(String source,String target) throws Exception {
        SftpATTRS before=file(source);
        if(source.equals(target)) return;
        directory(target.substring(0,target.lastIndexOf('/'))); absent(target);
        channel.rename(literal(source),literal(target));
        SftpATTRS after=file(target);
        if(after.getSize()!=before.getSize()) throw new IOException("Nie potwierdzono przeniesienia całego pliku.");
        absent(source);
    }
    public void delete(String path) throws Exception {
        file(path); channel.rm(literal(path)); absent(path);
    }
}
