package pl.ispinalokalnie.kindlewifi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 101;
    private static final String DESTINATION = "/mnt/us/documents";
    private static final int INK = 0xff182922;
    private static final int GREEN = 0xff165542;
    private SharedPreferences settings;
    private EditText address;
    private TextView status;
    private ProgressBar progress;
    private Button choose;
    private Button list;
    private String pendingAddress;
    private boolean sending;
    private final java.util.ArrayList<Uri> sharedFiles = new java.util.ArrayList<>();
    private TextView progressLabel;
    private Button history;
    private int currentFile, fileCount;
    private PdfEpubConverter.Options pdfOptions;
    private int pdfMode = 0; // 0 PDF only; 1 EPUB only; 2 PDF and EPUB

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(GREEN);
        settings = getSharedPreferences("kindle", MODE_PRIVATE);
        pendingAddress = state == null ? null : state.getString("pendingAddress");

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xfff4f7f2);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(25), dp(24), dp(24));
        scroll.addView(page);
        setContentView(scroll);

        TextView badge = label("ANDROID  →  KINDLE", 13, GREEN);
        badge.setTypeface(null, Typeface.BOLD);
        add(page, badge, 0);
        TextView title = label("Kindle przez Wi‑Fi 2.3", 30, INK);
        title.setTypeface(null, Typeface.BOLD);
        add(page, title, 10);
        add(page, label("Wyślij jedną książkę lub kilka naraz do KOReadera.", 17, INK), 8);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable surface = new GradientDrawable();
        surface.setColor(Color.WHITE);
        surface.setCornerRadius(dp(16));
        surface.setStroke(dp(1), 0xffd7e2d9);
        card.setBackground(surface);
        add(page, card, 24);

        TextView ipLabel = label("Adres IP Kindle’a", 16, INK);
        ipLabel.setTypeface(null, Typeface.BOLD);
        add(card, ipLabel, 0);
        address = new EditText(this);
        address.setId(View.generateViewId());
        ipLabel.setLabelFor(address.getId());
        address.setTextColor(INK);
        address.setSingleLine(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setText(settings.getString("address", "192.168.8.133"));
        address.setSelectAllOnFocus(true);
        add(card, address, 3);

        choose = new Button(this);
        choose.setText("Wybierz książki i wyślij");
        choose.setAllCaps(false);
        choose.setTextSize(16);
        choose.setTextColor(Color.WHITE);
        choose.setBackgroundTintList(ColorStateList.valueOf(GREEN));
        choose.setMinHeight(dp(54));
        choose.setOnClickListener(v -> {
            if (sharedFiles.isEmpty()) pickFile();
            else prepareBatch(new java.util.ArrayList<>(sharedFiles));
        });
        add(card, choose, 12);
        list = new Button(this);
        list.setText("Zarządzaj plikami na Kindle");
        list.setAllCaps(false);
        list.setOnClickListener(v -> {
            if (sending) return;
            final String host = address.getText().toString().trim();
            if (!privateAddress(host)) { address.setError("Wpisz adres IPv4 z KOReadera."); return; }
            settings.edit().putString("address", host).apply();
            busy(true);
            progress.setVisibility(View.GONE);
            new FileManager(this, () -> connect(host), () -> { busy(false); updateChoose(); }).show();
        });
        add(card, list, 6);
        history = new Button(this);
        history.setText("Historia przesyłek");
        history.setAllCaps(false);
        history.setOnClickListener(v -> showHistory());
        add(card, history, 6);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(GREEN));
        progress.setVisibility(View.GONE);
        add(card, progress, 10);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(GREEN));
        progressLabel = label("", 15, GREEN);
        add(card, progressLabel, 3);
        status = label(settings.getString("lastResult", "Książkę zapiszę w documents i sprawdzę jej zawartość."), 15, INK);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        add(card, status, 12);

        TextView instructions = label("Telefon i Kindle połącz z domowym Wi‑Fi. W KOReaderze włącz serwer SSH. "
                + "Jeśli korzystasz z logowania bez hasła, włączaj je tylko na czas przesyłania.", 15, INK);
        instructions.setLineSpacing(dp(3), 1f);
        add(page, instructions, 21);
        page.setFocusableInTouchMode(true);
        page.requestFocus();
        if (state != null) {
            java.util.ArrayList<Uri> saved = state.getParcelableArrayList("sharedFiles");
            if (saved != null) sharedFiles.addAll(saved);
            updateChoose();
        } else receiveShare(getIntent());
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putString("pendingAddress", pendingAddress);
        state.putParcelableArrayList("sharedFiles", sharedFiles);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private void add(LinearLayout layout, View child, int margin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(margin);
        layout.addView(child, params);
    }

    private void pickFile() {
        if (sending) return;
        String host = address.getText().toString().trim();
        if (!privateAddress(host)) {
            address.setError("Wpisz lokalny adres IPv4 pokazany przez KOReader.");
            return;
        }
        pendingAddress = host;
        settings.edit().putString("address", host).apply();
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(intent, PICK_FILE);
        } catch (android.content.ActivityNotFoundException e) {
            status.setText("Na telefonie brakuje systemowej aplikacji do wyboru plików.");
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILE || result != RESULT_OK || data == null || sending) return;
        prepareBatch(collectFiles(data, false));
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        receiveShare(intent);
    }

    private java.util.ArrayList<Uri> collectFiles(Intent intent, boolean share) {
        java.util.LinkedHashSet<Uri> files = new java.util.LinkedHashSet<>();
        if (share && Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())) {
            java.util.ArrayList<Uri> streams = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (streams != null) files.addAll(streams);
        } else if (share) {
            Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream != null) files.add(stream);
        } else if (intent.getData() != null) files.add(intent.getData());
        if (intent.getClipData() != null) {
            for (int i = 0; i < intent.getClipData().getItemCount(); i++) {
                Uri uri = intent.getClipData().getItemAt(i).getUri();
                if (uri != null) files.add(uri);
            }
        }
        java.util.ArrayList<Uri> safe = new java.util.ArrayList<>();
        for (Uri uri : files) {
            if (uri != null && "content".equals(uri.getScheme())) safe.add(uri);
        }
        return safe;
    }

    private void receiveShare(Intent intent) {
        if (intent == null || !(Intent.ACTION_SEND.equals(intent.getAction())
                || Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction()))) return;
        java.util.ArrayList<Uri> incoming = collectFiles(intent, true);
        for (Uri uri : incoming) if (!sharedFiles.contains(uri)) sharedFiles.add(uri);
        updateChoose();
        if (!sending) status.setText(sharedFiles.isEmpty()
                ? "Nie otrzymano pliku. W menedżerze plików wybierz książkę i Udostępnij."
                : "Gotowe do wysłania: " + sharedFiles.size() + " plików. Sprawdź IP i naciśnij Wyślij.");
        else android.widget.Toast.makeText(this, "Dodano książki do następnej przesyłki.", android.widget.Toast.LENGTH_LONG).show();
    }

    private void updateChoose() {
        choose.setText(sharedFiles.isEmpty() ? "Wybierz książki i wyślij"
                : "Wyślij udostępnione pliki (" + sharedFiles.size() + ")");
    }

    private void busy(boolean value) {
        sending = value;
        address.setEnabled(!value);
        choose.setEnabled(!value);
        list.setEnabled(!value);
        progress.setVisibility(value ? View.VISIBLE : View.GONE);
        if (value) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void prepareBatch(java.util.ArrayList<Uri> files) {
        if (sending || files.isEmpty()) return;
        boolean pdf = false;
        int pdfCount = 0;
        for (Uri uri : files) if (displayName(uri).toLowerCase(Locale.ROOT).endsWith(".pdf")) { pdf = true; pdfCount++; }
        if (!pdf) { pdfOptions = null; pdfMode = 0; startBatch(files); return; }
        final int numberPdf = pdfCount;
        final Uri previewUri = firstPdf(files);
        ScrollView scroll = new ScrollView(this);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(16),dp(8),dp(16),dp(8));
        scroll.addView(fields);
        add(fields,label("Co zrobić z plikami PDF? Oryginały na telefonie zawsze pozostają bez zmian.",16,INK),0);
        RadioGroup modes = new RadioGroup(this);
        String[] labels = {"Wyślij oryginalny PDF", "Przekonwertuj i wyślij EPUB", "Wyślij PDF i EPUB"};
        for (int i=0;i<3;i++) {
            RadioButton radio = new RadioButton(this);
            radio.setText(labels[i]); radio.setId(4000+i);
            modes.addView(radio);
        }
        modes.check(4001);
        add(fields,modes,8);
        add(fields,label("Ustawienia konwersji EPUB",17,GREEN),8);
        EditText title = field(fields, "Tytuł (pusty = nazwa PDF)", numberPdf==1 ? stem(displayName(previewUri)) : "");
        EditText author = field(fields, "Autor (opcjonalnie)", "");
        EditText language = field(fields, "Język (np. pl, de, en)", "pl");
        EditText first = field(fields, "Pierwsza strona", "1");
        first.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText last = field(fields, "Ostatnia strona (puste = koniec)", "");
        last.setInputType(InputType.TYPE_CLASS_NUMBER);
        CheckBox hyphens = new CheckBox(this); hyphens.setText("Łącz wyrazy dzielone na końcu linii"); hyphens.setChecked(true); add(fields,hyphens,4);
        CheckBox numbers = new CheckBox(this); numbers.setText("Usuń samodzielne numery stron"); numbers.setChecked(true); add(fields,numbers,0);
        CheckBox images = new CheckBox(this); images.setText("Dodaj osadzone ilustracje (większy EPUB)"); images.setChecked(false); add(fields,images,0);
        add(fields,label("PDF ze skanu bez tekstu wymaga OCR. Układ wielokolumnowy i tabele mogą nie zostać zachowane.",13,INK),8);
        Button preview = new Button(this); preview.setAllCaps(false); preview.setText("Podgląd tekstu z PDF");add(fields,preview,8);
        preview.setOnClickListener(v -> {
            PdfEpubConverter.Options opts;
            try { opts = getPdfOptions(title,author,language,first,last,hyphens,numbers,images); }
            catch (Exception e) { new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("OK",null).show(); return; }
            preview.setEnabled(false);
            new Thread(() -> {
                File pdfCopy = null; String result;
                try { pdfCopy = cachePdf(previewUri); result = PdfEpubConverter.preview(this,pdfCopy,opts); }
                catch (Exception error) { result = "Nie można przygotować podglądu: " + userMessage(error); }
                finally { if (pdfCopy != null) pdfCopy.delete(); }
                final String shown = result;
                runOnUiThread(() -> {preview.setEnabled(true); TextView view=label(shown,15,INK);view.setPadding(dp(16),dp(12),dp(16),dp(12));view.setTextIsSelectable(true);ScrollView box=new ScrollView(this);box.addView(view);new AlertDialog.Builder(this).setTitle("Podgląd konwersji").setView(box).setPositiveButton("Zamknij",null).show();});
            },"pdf-preview").start();
        });
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("PDF → EPUB")
            .setView(scroll).setNegativeButton("Anuluj",null)
            .setPositiveButton("Kontynuuj",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                int mode = modes.getCheckedRadioButtonId()-4000;
                if(mode<0 || mode>2) throw new IOException("Wybierz format przesyłki.");
                PdfEpubConverter.Options opts = mode == 0 ? null : getPdfOptions(title,author,language,first,last,hyphens,numbers,images);
                pdfMode = mode; pdfOptions = opts;
                dialog.dismiss(); startBatch(files);
            } catch(Exception error) { new AlertDialog.Builder(this).setMessage(error.getMessage()).setPositiveButton("OK",null).show(); }
        }));
        dialog.show();
    }

    private Uri firstPdf(java.util.ArrayList<Uri> files) {
        for(Uri uri:files) if(displayName(uri).toLowerCase(Locale.ROOT).endsWith(".pdf")) return uri;
        return files.get(0);
    }

    private EditText field(LinearLayout parent, String label, String defaultValue) {
        add(parent, label(label,13,INK),9);
        EditText edit = new EditText(this); edit.setSingleLine(true); edit.setText(defaultValue);
        add(parent,edit,0); return edit;
    }
    private static String stem(String name) { int dot=name.lastIndexOf('.'); return dot>0?name.substring(0,dot):name; }
    private static int numeric(EditText field, int fallback) throws IOException {
        String s=field.getText().toString().trim();
        if(s.isEmpty()) return fallback;
        try { return Integer.parseInt(s); } catch(NumberFormatException e) { throw new IOException("Nieprawidłowy zakres stron."); }
    }
    private PdfEpubConverter.Options getPdfOptions(EditText title,EditText author,EditText language,
            EditText first,EditText last,CheckBox hyphens,CheckBox numbers,CheckBox images) throws IOException {
        PdfEpubConverter.Options o=new PdfEpubConverter.Options();
        o.title=title.getText().toString().trim(); o.author=author.getText().toString().trim();
        o.language=language.getText().toString().trim();
        if(!o.language.matches("[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?")) throw new IOException("Język wpisz jako pl, de lub en.");
        o.firstPage=numeric(first,1); o.lastPage=numeric(last,0);
        if(o.firstPage<1 || (o.lastPage!=0 && o.lastPage<o.firstPage)) throw new IOException("Nieprawidłowy zakres stron.");
        o.joinHyphens=hyphens.isChecked(); o.removePageNumbers=numbers.isChecked(); o.includeImages=images.isChecked();
        return o;
    }
    private File cachePdf(Uri uri) throws IOException {
        File copy=File.createTempFile("pdf-source-",".pdf",getCacheDir());
        try (InputStream in=getContentResolver().openInputStream(uri); java.io.OutputStream out=new java.io.FileOutputStream(copy)) {
            if (in==null) throw new IOException("Nie można odczytać PDF.");
            byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
        } catch(IOException e) { copy.delete(); throw e; }
        if(copy.length()==0) { copy.delete(); throw new IOException("PDF jest pusty."); }
        return copy;
    }
    private String convertAndSend(String host, Uri uri, boolean sendPdf) throws Exception {
        File cached = cachePdf(uri);
        File epub = File.createTempFile("kindle-converted-", ".epub",getCacheDir());
        epub.delete();
        try {
            String base = stem(displayName(uri));
            runOnUiThread(() -> { progress.setIndeterminate(true);status.setText("Konwertuję PDF na EPUB na telefonie…"); });
            PdfEpubConverter.Options current = new PdfEpubConverter.Options();
            current.title=pdfOptions.title;current.author=pdfOptions.author;current.language=pdfOptions.language;
            current.firstPage=pdfOptions.firstPage;current.lastPage=pdfOptions.lastPage;
            current.joinHyphens=pdfOptions.joinHyphens;current.removePageNumbers=pdfOptions.removePageNumbers;current.includeImages=pdfOptions.includeImages;
            // A custom title is applied only to a single PDF. The filename stays specific per file.
            if(fileCount>1) current.title=base;
            PdfEpubConverter.convert(this,cached,epub,current,(page,total) -> runOnUiThread(() ->
                    status.setText("Konwersja PDF → EPUB: strona " + page + " z " + total)));
            saveEpub(epub,base+".epub");
            if(sendPdf) runOnUiThread(() -> status.setText("Wysyłam oryginalny PDF…"));
            String pdfPath=sendPdf ? send(host,uri) : "";
            String epubPath=uploadFile(host,epub,base+".epub");
            return sendPdf ? pdfPath+"\n"+epubPath : epubPath;
        } finally { cached.delete();epub.delete(); }
    }
    private void saveEpub(File epub, String name) throws IOException {
        if(Build.VERSION.SDK_INT >= 29) {
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
            values.put(MediaStore.MediaColumns.MIME_TYPE,"application/epub+zip");
            values.put("relative_path",Environment.DIRECTORY_DOWNLOADS+"/Kindle przez WiFi");
            Uri target=getContentResolver().insert(Uri.parse("content://media/external/downloads"),values);
            if(target==null) throw new IOException("Nie udało się zapisać EPUB w Pobranych.");
            try (InputStream in=new java.io.FileInputStream(epub);
                 java.io.OutputStream out=getContentResolver().openOutputStream(target)) {
                if(out==null) throw new IOException("Nie można zapisać EPUB w Pobranych.");
                byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
            } catch(IOException e) {getContentResolver().delete(target,null,null);throw e;}
        } else {
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"EPUB");
            if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Brak folderu na EPUB.");
            File dest=new File(dir,name);
            int i=2;while(dest.exists())dest=new File(dir,stem(name)+" ("+(i++)+").epub");
            try(InputStream in=new java.io.FileInputStream(epub);java.io.OutputStream out=new java.io.FileOutputStream(dest)){
                byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
            }
        }
    }

    private void startBatch(java.util.ArrayList<Uri> files) {
        if (sending || files.isEmpty()) return;
        final String host = address.getText().toString().trim();
        if (!privateAddress(host)) { address.setError("Wpisz adres IPv4 z KOReadera."); return; }
        settings.edit().putString("address", host).apply();
        sharedFiles.removeAll(files);
        updateChoose();
        busy(true);
        status.setText("Przygotowuję przesyłkę…");
        progressLabel.setText("");
        new Thread(() -> {
            int ok = 0;
            StringBuilder report = new StringBuilder();
            fileCount = files.size();
            for (int i = 0; i < files.size(); i++) {
                currentFile = i + 1;
                Uri uri = files.get(i);
                String name = "Książka " + currentFile;
                String id = java.util.UUID.randomUUID().toString();
                try {
                    name = displayName(uri);
                    record(id, name, host, "W trakcie / jeszcze niepotwierdzona", "");
                    final String shownName = name;
                    final int index = currentFile, total = fileCount;
                    runOnUiThread(() -> {
                        progress.setIndeterminate(true);
                        progressLabel.setText("Książka " + index + " z " + total);
                        status.setText("Przygotowuję: " + shownName);
                    });
                    boolean pdf = name.toLowerCase(Locale.ROOT).endsWith(".pdf");
                    String path = pdf && pdfMode != 0 && pdfOptions != null
                            ? convertAndSend(host, uri, pdfMode == 2)
                            : send(host, uri);
                    record(id, name, host, "Zapisano i sprawdzono", path);
                    ok++;
                    report.append("✓ ").append(path).append('\n');
                } catch (Exception error) {
                    String detail = userMessage(error);
                    record(id, name, host, "Niepotwierdzona", detail);
                    report.append("✗ ").append(name).append(": ").append(detail).append('\n');
                }
            }
            final String result = "Zapisano i sprawdzono: " + ok + " z " + files.size()
                    + "\n\n" + report + "\nW KOReaderze otwórz documents. Wyjdź z folderu i wejdź ponownie, aby odświeżyć listę.";
            settings.edit().putString("lastResult", result).apply();
            runOnUiThread(() -> { busy(false); progressLabel.setText("Zakończono przesyłkę"); status.setText(result); updateChoose(); });
        }, "kindle-batch").start();
    }

    private synchronized void record(String id, String name, String host, String result, String detail) {
        try {
            org.json.JSONArray old = new org.json.JSONArray(settings.getString("history", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            org.json.JSONObject item = new org.json.JSONObject();
            item.put("id", id); item.put("name", name); item.put("host", host);
            item.put("time", System.currentTimeMillis()); item.put("result", result); item.put("detail", detail);
            next.put(item);
            for (int i = 0; i < old.length() && next.length() < 100; i++) {
                org.json.JSONObject existing = old.getJSONObject(i);
                if (!id.equals(existing.optString("id"))) next.put(existing);
            }
            settings.edit().putString("history", next.toString()).commit();
        } catch (org.json.JSONException ignored) { }
    }

    private void showHistory() {
        StringBuilder text = new StringBuilder();
        try {
            org.json.JSONArray items = new org.json.JSONArray(settings.getString("history", "[]"));
            java.text.DateFormat date = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
            for (int i = 0; i < items.length(); i++) {
                org.json.JSONObject item = items.getJSONObject(i);
                text.append(date.format(new java.util.Date(item.getLong("time")))).append(" • ")
                    .append(item.optString("name")).append('\n').append(item.optString("result"))
                    .append(" • ").append(item.optString("host")).append('\n')
                    .append(item.optString("detail")).append("\n\n");
            }
        } catch (org.json.JSONException e) { text.append("Nie można odczytać historii."); }
        if (text.length() == 0) text.append("Historia nowych przesyłek pojawi się tutaj.");
        TextView content = label(text.toString(), 16, INK);
        content.setPadding(dp(20), dp(12), dp(20), dp(12));
        content.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Historia — ostatnie 100 plików")
                .setView(scroll).setPositiveButton("Zamknij", null).show();
    }

    @Override public void onBackPressed() {
        if (sending) android.widget.Toast.makeText(this, "Poczekaj na zakończenie przesyłania.", android.widget.Toast.LENGTH_SHORT).show();
        else super.onBackPressed();
    }

    private static boolean privateAddress(String host) {
        if (host == null || !host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        String[] parts = host.split("\\.");
        int[] octet = new int[4];
        for (int i = 0; i < 4; i++) {
            octet[i] = Integer.parseInt(parts[i]);
            if (octet[i] > 255 || !Integer.toString(octet[i]).equals(parts[i])) return false;
        }
        return octet[0] == 10 || (octet[0] == 172 && octet[1] >= 16 && octet[1] <= 31)
                || (octet[0] == 192 && octet[1] == 168);
    }

    private Session connect(String host) throws Exception {
        JSch ssh = new JSch();
        File knownHosts = new File(getFilesDir(), "known_hosts");
        if (!knownHosts.exists()) knownHosts.createNewFile();
        ssh.setKnownHosts(knownHosts.getPath());
        Session session = ssh.getSession("root", host, 2222);
        session.setPassword("root");
        session.setConfig("StrictHostKeyChecking", "ask");
        session.setConfig("PreferredAuthentications", "password,keyboard-interactive");
        String hostKeys = session.getConfig("server_host_key");
        if (!java.util.Arrays.asList(hostKeys.split(",")).contains("ssh-rsa")) {
            session.setConfig("server_host_key", hostKeys + ",ssh-rsa");
        }
        session.setUserInfo(new UserInfo() {
            public String getPassphrase() { return null; }
            public String getPassword() { return "root"; }
            public boolean promptPassword(String message) { return false; }
            public boolean promptPassphrase(String message) { return false; }
            public void showMessage(String message) { }
            public boolean promptYesNo(String message) {
                if (message == null || !message.contains("authenticity") || !message.contains("fingerprint")) {
                    return false;
                }
                return confirmHost(host);
            }
        });

        try {
            session.connect(12000);
            session.setTimeout(30000);
            return session;
        } catch (Exception e) { session.disconnect(); throw e; }
    }

    private String send(String host, Uri file) throws Exception {
        File cached = File.createTempFile("upload-", ".tmp", getCacheDir());
        try {
            String name = displayName(file);
            String lower = name.toLowerCase(Locale.ROOT);
            if (!(lower.endsWith(".epub") || lower.endsWith(".pdf") || lower.endsWith(".mobi")
                    || lower.endsWith(".azw") || lower.endsWith(".azw3") || lower.endsWith(".fb2")
                    || lower.endsWith(".txt") || lower.endsWith(".djvu") || lower.endsWith(".cbz"))) {
                throw new IOException("Wybierz książkę, np. plik z końcówką .epub lub .pdf.");
            }
            try (InputStream in = getContentResolver().openInputStream(file);
                 java.io.OutputStream out = new java.io.FileOutputStream(cached)) {
                if (in == null) throw new IOException("Nie można otworzyć pliku na telefonie.");
                byte[] buffer = new byte[32768];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
            if (lower.endsWith(".epub")) {
                try (java.util.zip.ZipFile epub = new java.util.zip.ZipFile(cached)) {
                    if (epub.getEntry("META-INF/container.xml") == null)
                        throw new IOException("Ten plik nie zawiera struktury książki EPUB.");
                }
            }
            return uploadFile(host,cached,name);
        } finally { cached.delete(); }
    }

    private String uploadFile(String host, File source, String name) throws Exception {
        Session session=null;
        ChannelSftp channel=null;
        try {
            session=connect(host);
            channel=(ChannelSftp)session.openChannel("sftp");
            channel.connect(12000);
            if(!channel.stat("/mnt/us/koreader").isDir())
                throw new IOException("Pod tym adresem nie znaleziono folderu KOReadera.");
            return VerifiedTransfer.upload(channel,source,name,DESTINATION,
                text -> runOnUiThread(() -> status.setText(text)),
                percent -> {
                    final int index = currentFile, total = fileCount;
                    runOnUiThread(() -> {
                        progress.setIndeterminate(false);
                        progress.setProgress(percent);
                        progressLabel.setText("Książka " + index + " z " + total + " • " + percent + "%");
                    });
                });
        } finally {
            if(channel!=null)channel.disconnect();
            if(session!=null)session.disconnect();
        }
    }

    private void showRemoteFiles() {
        if (sending) return;
        final String host = address.getText().toString().trim();
        if (!privateAddress(host)) {
            address.setError("Wpisz lokalny adres IPv4 pokazany przez KOReader.");
            return;
        }
        settings.edit().putString("address", host).apply();
        sending = true;
        address.setEnabled(false);
        choose.setEnabled(false);
        list.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        progressLabel.setText("");
        status.setText("Odczytuję pliki bezpośrednio z Kindle…");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        new Thread(() -> {
            Session session = null;
            ChannelSftp channel = null;
            String message;
            try {
                session = connect(host);
                channel = (ChannelSftp) session.openChannel("sftp");
                channel.connect(12000);
                message = "Pliki na Kindle (" + host + "):\n\n"
                        + VerifiedTransfer.list(channel, DESTINATION);
                try { message += "\nStarsze przesyłki:\n" + VerifiedTransfer.list(channel, "/mnt/us/Books"); }
                catch (SftpException e) {
                    if (e.id != ChannelSftp.SSH_FX_NO_SUCH_FILE) throw e;
                }
            } catch (Exception error) {
                message = userMessage(error);
            } finally {
                if (channel != null) channel.disconnect();
                if (session != null) session.disconnect();
            }
            final String result = message;
            runOnUiThread(() -> {
                sending = false;
                address.setEnabled(true);
                choose.setEnabled(true);
                list.setEnabled(true);
                progress.setVisibility(View.GONE);
                status.setText(result);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }, "kindle-list").start();
    }

    private boolean confirmHost(String host) {
        AtomicBoolean accepted = new AtomicBoolean();
        CountDownLatch latch = new CountDownLatch(1);
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) {
                latch.countDown();
                return;
            }
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Połączyć z Kindle’em?")
                    .setMessage("Jeśli KOReader pokazuje adres " + host + ", wybierz Połącz.")
                    .setPositiveButton("Połącz", (d, which) -> accepted.set(true))
                    .setNegativeButton("Anuluj", (d, which) -> {})
                    .create();
            dialog.setOnDismissListener(d -> latch.countDown());
            dialog.show();
            new android.os.Handler(getMainLooper()).postDelayed(() -> {
                if (dialog.isShowing()) dialog.dismiss();
            }, 60000);
        });
        try {
            return latch.await(62, TimeUnit.SECONDS) && accepted.get();
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private String displayName(Uri file) {
        String name = "plik";
        try (Cursor cursor = getContentResolver().query(file,
                new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && cursor.getString(0) != null) {
                name = cursor.getString(0);
            }
        }
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (name.endsWith(".") || name.endsWith(" ")) name = name.substring(0, name.length() - 1);
        if (name.isEmpty()) return "plik";
        if (name.startsWith(".")) name = "plik" + name;
        int dot = name.lastIndexOf('.');
        String suffix = dot > 0 && name.length() - dot <= 20 ? name.substring(dot) : "";
        if (name.getBytes(StandardCharsets.UTF_8).length > 220) {
            String stem = name.substring(0, name.length() - suffix.length());
            while ((stem + suffix).getBytes(StandardCharsets.UTF_8).length > 220) {
                stem = stem.substring(0, stem.offsetByCodePoints(stem.length(), -1));
            }
            name = stem + suffix;
        }
        return name;
    }

    private static String userMessage(Exception error) {
        String detail = error.getMessage() == null ? "" : error.getMessage();
        if (error instanceof JSchException) {
            String lower = detail.toLowerCase(Locale.ROOT);
            if (lower.contains("reject hostkey") || lower.contains("hostkey has been changed")) {
                return "Nie potwierdzono tożsamości Kindle’a. Sprawdź adres na ekranie KOReadera.";
            }
            if (lower.contains("auth")) {
                return "Kindle odrzucił logowanie. W KOReaderze zatrzymaj SSH, włącz „Logowanie bez hasła” i uruchom SSH ponownie.";
            }
            return "Nie udało się połączyć. Sprawdź adres Kindle’a, włączony serwer SSH i wspólne domowe Wi‑Fi.\n" + detail;
        }
        if (error instanceof SftpException) {
            return "Nie potwierdzono operacji na Kindle. Sprawdź folder documents i wolne miejsce.\n" + detail;
        }
        return "Zapis niepotwierdzony. " + detail;
    }
}
