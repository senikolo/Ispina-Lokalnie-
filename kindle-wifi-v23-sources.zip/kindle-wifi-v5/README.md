# Kindle przez Wi-Fi 2.2

Android 8+, natywny klient SFTP do wbudowanego SSH KOReadera, port 2222.
Nie wymaga wtyczki ani zmiany plików KOReadera. Aktualizacja aplikacji 1.0, 1.1, 2.0 i 2.1.

## Użycie
1. Zainstaluj APK jako aktualizację poprzedniej aplikacji.
2. Telefon i Kindle połącz z tą samą domową siecią Wi-Fi.
3. W KOReaderze uruchom serwer SSH. Aplikacja obsługuje istniejącą konfigurację
   logowania bez hasła lub hasło root; nie zmienia konfiguracji czytnika.
4. Wpisz bieżący adres IP wyświetlany w KOReaderze.
5. Naciśnij „Wybierz plik i wyślij”. Wybierz EPUB lub inną książkę.
6. Poczekaj na „Zapisano i sprawdzono zawartość książki”.
7. Na Kindle otwórz w KOReaderze /mnt/us/documents. Jeśli lista była już otwarta,
   wyjdź z folderu i otwórz go ponownie, aby odświeżyć widok.
8. Przycisk „Pokaż pliki na Kindle” odczytuje documents i dawny Books z czytnika.
   Po przesłaniu możesz wyłączyć SSH.

EPUB otwieraj w KOReaderze; natywna biblioteka Kindle nie wyświetla EPUB.

## Weryfikacja
Plik jest buforowany na telefonie, zapisywany pod tymczasową nazwą, sprawdzany
pod względem rozmiaru i przemianowywany. Aplikacja odczytuje całą kopię z czytnika
przez SFTP i porównuje SHA-256 z lokalnym plikiem przed komunikatem sukcesu.
Pusty plik, błędna struktura EPUB, brak katalogu, błąd odczytu lub niezgodna
zawartość nie powodują komunikatu sukcesu. Istniejące książki nie są nadpisywane.
Niepotwierdzony plik po przemianowaniu może pozostać na czytniku; aplikacja
zgłasza błąd weryfikacji. Nie usuwa istniejących książek.

## Testy wykonane
Integracja rzeczywistej klasy VerifiedTransfer z lokalnym OpenSSH/SFTP:
- transfer 2 MB, odczyt SHA-256, polskie znaki, spacje, nawiasy w nazwie;
- duplikat zachowany z dopiskiem (2), lista nazw i rozmiarów z serwera;
- odrzucenie uszkodzenia o tym samym rozmiarze i uciętego pliku;
- odrzucenie pustego źródła i brakującego folderu docelowego.
Kompilacja APK oraz weryfikacja podpisu V2 i zgodności klucza ze starszą wersją.
Nie wykonano testu na fizycznym Kindle ani emulatorze Androida.
Przyczyna braku plików na czytniku użytkownika nie została jednoznacznie ustalona.

## Budowanie
Java 21 (JRE wystarczy), Python 3, curl, unzip, Linux x86_64.
Ustaw KINDLE_APK_KEY_PASSWORD, uruchom bash build.sh. Narzędzia są pobierane
z Maven Central w wersjach przypiętych w skrypcie. Zachowaj klucz podpisujący
ze swojego katalogu .build-work. Prywatny klucz wydania nie jest dołączony.

## Nowości 2.1
- Wiele książek z systemowego selektora (przytrzymaj plik, zaznacz następne).
- Udostępnij z innej aplikacji: ACTION_SEND i ACTION_SEND_MULTIPLE.
  Książki trafiają do kolejki; naciśnij Wyślij, aby rozpocząć.
- Licznik książek oraz procent dla bieżącej książki: 0–50 wysyłanie,
  50–99 ponowny odczyt i weryfikacja; 100 dopiero po zgodności SHA-256.
  Podczas przygotowania i łączenia pasek jest nieokreślony.
- Historia ostatnich 100 plików: data, nazwa, IP, wynik, ścieżka lub błąd.
  Przetrwa zamknięcie aplikacji i aktualizację, ale nie odinstalowanie.
  Przerwane przesyłki pozostają niepotwierdzone. Stare wysyłki sprzed 2.1
  nie są odtwarzane. Błąd jednego pliku nie zatrzymuje kolejnych.
- Używaj aplikacji na pierwszym planie podczas przesyłania; nie jest to usługa
  działająca w tle. System może przerwać pracę aplikacji po jej opuszczeniu.

Test 2.1 potwierdził postęp 0–100, monotoniczność oraz etap weryfikacji 50–99,
przesyłanie kolejnych plików, ochronę duplikatów i dotychczasowe testy błędów.
Podpis nowego APK zweryfikowany względem wersji 2.0. Integracja systemowego
Udostępnij, selektor wielokrotnego wyboru i historia nie były uruchomione na
fizycznym Androidzie ani emulatorze; sprawdzono kod i zbudowany manifest.

## Nowości 2.2 — menedżer plików
Przycisk „Zarządzaj plikami na Kindle” otwiera documents. „Foldery” przełącza
pomiędzy documents i Books. Dotknij folderu, aby wejść; W górę wraca do rodzica.
Wyszukiwanie filtruje aktualny folder (nie przeszukuje całego czytnika).
Zaznacz jedną książkę do zmiany nazwy. Końcówka formatu pozostaje zachowana.
Usuwanie zaznaczonych książek jest trwałe i wymaga potwierdzenia z listą nazw.
Można tworzyć foldery i przenosić zaznaczone książki do wskazanego folderu.
Nie nadpisuje istniejących plików. Pokazuje osobny wynik operacji każdej książki.
Nie usuwa folderów i nie udostępnia plików systemowych ani dowiązań symbolicznych.
Operacje dozwolone są wyłącznie wewnątrz documents oraz Books.

Przed zmianą nazwy, przeniesieniem lub usuwaniem zamknij daną książkę
w KOReaderze. Edytowana jest nazwa pliku, nie tytuł w metadanych EPUB.
Ta wersja nie przenosi katalogów .sdr ani nie zmienia historii KOReadera:
zakładki i postęp czytania mogą pozostać przypisane do poprzedniej lokalizacji.
KOReader ma kilka sposobów przechowywania tych danych; patrz:
https://koreader.rocks/doc/modules/docsettings.html

Testy 2.2 na rzeczywistym serwerze OpenSSH/SFTP:
- lista, filtrowanie plików książek, foldery i polskie znaki;
- zmiana nazwy zachowuje bajty, przenoszenie między roots i do podfolderów;
- usunięcie potwierdzone bezpośrednio na dysku serwera;
- blokada kolizji nazw, zmiany rozszerzenia, wyjścia poza katalogi książek;
- blokada usuwania plików innych niż książki, katalogów i dowiązań;
- pliki niezwiązane z operacją pozostały nienaruszone;
- poprawny podpis APK i ten sam certyfikat co wersja 2.1.
Nie wykonano testu interfejsu na Androidzie ani transferu na fizycznym Kindle.

## Stan projektu 2.3 (wersja źródłowa, nieprzetestowana APK)

Przygotowano **kod źródłowy** konwertera PDF → EPUB. W tej paczce nie ma
zbudowanej aplikacji 2.3 ani potwierdzenia uruchomienia na telefonie. Składnia
wszystkich plików Java przeszła kontrolę parserem Javy, lecz kompilacja Androida
wymaga narzędzi i zależności z Maven Central. Nie przedstawiać kodu jako gotowego
APK bez pomyślnej kompilacji, sprawdzenia podpisu i testów.

Planowane zachowanie 2.3:
- Po wyborze PDF użytkownik może wysłać oryginalny PDF, tylko nowy EPUB albo oba.
- PDF jest **zawsze zachowywany na telefonie**; program nigdy go nie kasuje.
- EPUB powstaje lokalnie bez wysyłania treści na serwer (biblioteka PdfBox-Android).
- Dostępne: tytuł, autor, język, zakres stron, łączenie dzielonych wyrazów,
  usuwanie odrębnych numerów stron, opcjonalne osadzone ilustracje i podgląd.
- Konwersja zdjęć/skanów bez tekstu do EPUB nie jest obsługiwana: wymaga OCR.
- W Androidzie 10+ EPUB jest kopiowany do Pobrane/Kindle przez WiFi; w starszych
  systemach do prywatnego katalogu Documents/EPUB aplikacji.
- Pliki EPUB są wysyłane do /mnt/us/documents i weryfikowane za pomocą SHA-256,
  tak samo jak inne przesyłki w wersji 2.2.
- Wersja 2.3 ma **osobny identyfikator Android** (`pl.ispinalokalnie.kindlewifi.v23`),
  ponieważ w otrzymanych źródłach nie było prywatnego klucza podpisującego 2.2.
  Dzięki temu instalacja testowej wersji nie wymaga odinstalowania działającej 2.2
  i nie usuwa jej historii. 2.2 i 2.3 będą miały osobne ustawienia/historie.

### Budowanie

Do skompilowania potrzebny jest Linux, internet do Maven Central, Java 21,
Python 3 i curl. Uruchom `KINDLE_APK_KEY_PASSWORD='wybrane-haslo' bash build.sh
Kindle-przez-WiFi-2.3.apk`. Skrypt pobiera przypięte zależności i podpisuje APK
nowym kluczem w katalogu `.build-work` (klucz **zachowaj** do przyszłych aktualizacji).
Nie wolno sugerować aktualizacji na istniejące 2.2 innym kluczem.
