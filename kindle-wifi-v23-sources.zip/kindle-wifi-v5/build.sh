#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
tools="${KINDLE_BUILD_TOOLS:-$project/.build-tools}"
work="${KINDLE_BUILD_WORK:-$project/.build-work}"
output="${1:-$project/Kindle-przez-WiFi.apk}"
: "${KINDLE_APK_KEY_PASSWORD:?Ustaw hasło klucza podpisującego}"
mkdir -p "$tools" "$work/classes" "$work/dex" "$work/signer" "$(dirname "$output")"

fetch() {
    if [[ ! -s "$tools/$1" ]]; then
        curl --fail --silent --show-error --location --retry 2 \
            "https://repo.maven.apache.org/maven2/$2" -o "$tools/$1.tmp"
        mv "$tools/$1.tmp" "$tools/$1"
    fi
}

fetch ecj.jar org/eclipse/jdt/ecj/3.38.0/ecj-3.38.0.jar
fetch r8.jar net/mbonnin/r8/r8/8.3.8/r8-8.3.8.jar
fetch android.jar org/robolectric/android-all/6.0.1_r3-robolectric-r1/android-all-6.0.1_r3-robolectric-r1.jar
fetch apksig.jar com/android/tools/build/apksig/2.3.0/apksig-2.3.0.jar
fetch jsch.jar com/github/mwiede/jsch/0.2.21/jsch-0.2.21.jar
fetch apktool-lib.jar org/apktool/apktool-lib/3.0.3/apktool-lib-3.0.3.jar
fetch pdfbox-android.aar com/tom-roush/pdfbox-android/2.0.27.0/pdfbox-android-2.0.27.0.aar
fetch bcprov.jar org/bouncycastle/bcprov-jdk15to18/1.72/bcprov-jdk15to18-1.72.jar
fetch bcpkix.jar org/bouncycastle/bcpkix-jdk15to18/1.72/bcpkix-jdk15to18-1.72.jar
fetch bcutil.jar org/bouncycastle/bcutil-jdk15to18/1.72/bcutil-jdk15to18-1.72.jar
unzip -p "$tools/pdfbox-android.aar" classes.jar > "$work/pdfbox-classes.jar"

unzip -p "$tools/apktool-lib.jar" prebuilt/linux/aapt2 > "$tools/aapt2"
chmod +x "$tools/aapt2"
unzip -p "$tools/apktool-lib.jar" prebuilt/android-framework.jar > "$tools/framework.jar"

java -jar "$tools/ecj.jar" -proc:none -encoding UTF-8 -1.8 -nowarn \
    -classpath "$tools/android.jar:$tools/jsch.jar:$work/pdfbox-classes.jar" -d "$work/classes" \
    "$project"/src/pl/ispinalokalnie/kindlewifi/*.java
java -jar "$tools/ecj.jar" -proc:none -1.8 -nowarn \
    -classpath "$tools/apksig.jar" -d "$work/signer" "$project/SignApk.java"

python3 - "$tools/jsch.jar" "$work/jsch-android.jar" <<'PY'
from sys import argv
from zipfile import ZipFile

with ZipFile(argv[1]) as source, ZipFile(argv[2], "w") as target:
    for name in source.namelist():
        if name.startswith("com/") and name.endswith(".class"):
            target.writestr(name, source.read(name))
PY

"$tools/aapt2" compile --dir "$project/res" -o "$work/resources.zip"
"$tools/aapt2" link -I "$tools/framework.jar" --manifest "$project/AndroidManifest.xml" \
    -o "$work/unsigned.apk" "$work/resources.zip"
mapfile -t classes < <(find "$work/classes" -name '*.class')
java -cp "$tools/r8.jar" com.android.tools.r8.D8 --min-api 26 --lib "$tools/android.jar" \
    --output "$work/dex" "$work/jsch-android.jar" "$work/pdfbox-classes.jar" "$tools/bcprov.jar" "$tools/bcpkix.jar" "$tools/bcutil.jar" "${classes[@]}"

python3 - "$work/unsigned.apk" "$work/dex/classes.dex" "$tools/jsch.jar" "$tools/pdfbox-android.aar" <<'PY'
from sys import argv
from zipfile import ZIP_DEFLATED, ZipFile

with ZipFile(argv[1], "a", compression=ZIP_DEFLATED) as apk, ZipFile(argv[3]) as dependency:
    apk.write(argv[2], "classes.dex")
    for name in dependency.namelist():
        if name.startswith("META-INF/LICENSE"):
            apk.writestr(name, dependency.read(name))
    with ZipFile(argv[4]) as pdfbox:
        for name in pdfbox.namelist():
            if name.startswith("assets/") and not name.endswith("/"):
                apk.writestr(name, pdfbox.read(name))
PY

signing_key="${KINDLE_APK_KEYSTORE:-$work/kindle-wifi.p12}"
if [[ ! -f "$signing_key" ]]; then
    keytool -genkeypair -alias kindle-wifi -keyalg RSA -keysize 3072 -validity 10000 \
        -dname "CN=Kindle przez WiFi" -storetype PKCS12 -keystore "$signing_key" \
        -storepass:env KINDLE_APK_KEY_PASSWORD -keypass:env KINDLE_APK_KEY_PASSWORD
fi
java --add-exports=java.base/sun.security.x509=ALL-UNNAMED -cp "$tools/apksig.jar:$work/signer" SignApk "$signing_key" "$work/unsigned.apk" "$output"
