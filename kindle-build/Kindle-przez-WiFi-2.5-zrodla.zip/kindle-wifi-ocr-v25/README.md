# Kindle przez Wi-Fi 2.5, wersja testowa

Aplikacja Android do przesyłania EPUB, PDF, MOBI, AZW3, FB2 i TXT przez SSH/SFTP do `/mnt/us/documents` na Kindle Keyboard 3 Wi-Fi z KOReaderem. Serwer SSH KOReadera musi być włączony. Telefon i Kindle powinny być w tej samej, zaufanej sieci lokalnej. Nie trzeba instalować dodatkowych wtyczek KOReadera.

## Co poprawiono w 2.5

- Weryfikacja SHA-256 na pliku tymczasowym przed nadaniem mu końcowej nazwy. Uszkodzony plik nie powinien pojawić się jako gotowa książka.
- Przy PDF i EPUB: niezależne wyniki dla wysłanego PDF, konwersji EPUB, kopii EPUB w telefonie i przesłania EPUB na Kindle. Błąd konwersji nie blokuje już przesłania PDF.
- Przycisk przerywania przesyłki oraz konwersji, z przerwaniem wątku i próbą usunięcia pliku tymczasowego.
- Informacja o stronach PDF bez rozpoznanego tekstu; podgląd nie myli numerów stron z odczytanym tekstem.
- Czytelniejsze komunikaty i nazwy przycisków; bezpieczne przechowywanie ostatniego adresu Kindle i historii.
- Aktualizacja numeru wersji na 2.5 (`versionCode 8`); identyfikator pakietu bez zmian od 2.3.

## Jak zbudować

Wymagania: JDK 17 lub nowszy, Gradle 8.7, Android SDK 35, Google Maven i Maven Central.

```bash
bash build.sh
```

Powstanie **niepodpisany** plik `build/outputs/apk/release/KindleOcr-release-unsigned.apk` (nazwa może być `app-release-unsigned.apk`, zależnie od konfiguracji). Przed instalacją podpisz go certyfikatem używanym do wcześniejszych wersji 2.3/2.4, aby aktualizacja była możliwa bez odinstalowania aplikacji. Nie publikuj prywatnego klucza podpisu w repozytorium ani w logach CI.

### Weryfikacja

- Test lokalny przy użyciu fikcyjnego serwera SFTP: `bash tests/run-atomic-tests.sh`. Testuje odrzucenie uszkodzonej kopii, brak pozostałości `.part`, ponowienie, ochronę istniejącego pliku i anulowanie.
- Rzeczywista transmisja, logowanie, wydajność OCR i instalacja na Androidzie 10 **nie zostały przeze mnie zweryfikowane na urządzeniach**.
- Do czasu wdrożenia logowania kluczem SSH uruchamiaj serwer SSH KOReadera tylko na czas transferu i wyłącznie w zaufanym Wi-Fi. Potwierdzaj odcisk klucza przy pierwszym połączeniu.

**Ważne:** Jeśli Wi-Fi zerwie się podczas uploadu, na Kindle może pozostać ukryty plik `.kindle-upload-....part`. Nie powinien zostać uznany za gotową książkę. Nie przerywaj instalacji KOReadera ani nie kasuj jego katalogów.

## Otwarte kwestie

- Parowanie własnym kluczem SSH zamiast hasła/bezhasłowego SSH wymaga dodatkowej zgodności z konfiguracją serwera KOReadera.
- Nie wszystkie skany PDF dają użyteczny tekst. Tabele, zdjęcia i zeskanowane strony trzeba sprawdzić w podglądzie.
- Brak wznowienia uploadu od bajtu, w którym zerwało się połączenie. Ponowienie zaczyna przesyłkę od początku.
