#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/mock-tests
javac -encoding UTF-8 -d build/mock-tests \
  src/pl/ispinalokalnie/kindlewifi/VerifiedTransfer.java \
  $(find tests/mock/src -name '*.java')
java -Dfile.encoding=UTF-8 -cp build/mock-tests VerifyAtomicTest
