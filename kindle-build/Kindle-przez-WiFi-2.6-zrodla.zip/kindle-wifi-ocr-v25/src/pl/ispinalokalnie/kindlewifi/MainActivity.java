package pl.ispinalokalnie.kindlewifi;

import android.app.Activity;
import android.view.animation.OvershootInterpolator;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private static final int PICK_FILE = 101;
    private static final String DESTINATION = "/mnt/us/documents";
    private static final int INK = 0xff20372d;
    private static final int GREEN = 0xff19764b;
    private static final int SUCCESS = 0xff16994e;
    private static final int MUTED = 0xff62756a;
    private static final int BG = 0xfff5f8f4;
    private static final int BORDER = 0xffe0e9df;
    private SharedPreferences settings;
    private EditText address;
    private TextView status;
    private TextView stateTitle;
    private TextView stateIcon;
    private Button detailsButton;
    private String lastDetails = "";
    private LinearLayout stateCard;
    private LinearLayout confirmedRows;
    private ProgressBar progress;
    private Button choose;
    private Button list;
    private String pendingAddress;
    private boolean sending;
    private final java.util.ArrayList<Uri> sharedFiles = new java.util.ArrayList<>();
    private TextView progressLabel;
    private Button history;
    private Button cancelButton;
    private volatile Thread transferThread;
    private volatile boolean cancellationRequested;
    private int currentFile, fileCount;
    private PdfEpubConverter.Options pdfOptions;
    private int pdfMode = 0; // 0 PDF only; 1 EPUB only; 2 PDF and EPUB

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(GREEN);
        settings = getSharedPreferences("kindle", MODE_PRIVATE);
        pendingAddress = state == null ? null : state.getString("pendingAddress");

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(36));
        scroll.addView(page);
        setContentView(scroll);

        // Czytelny nagłówek zamiast technicznej tablicy diagnostycznej.
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView brandIcon = label("📚", 25, GREEN);
        brandIcon.setGravity(android.view.Gravity.CENTER);
        brandIcon.setBackground(rounded(0xffe3efe3, 15, 0));
        brand.addView(brandIcon, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(12), 0, 0, 0);
        TextView brandName = label("Kindle przez Wi-Fi", 20, INK);
        brandName.setTypeface(null, Typeface.BOLD);
        brandText.addView(brandName);
        brandText.addView(label("Twoje książki, bez kabla", 13, MUTED));
        brand.addView(brandText);
        add(page, brand, 0);

        TextView hero = label("Wyślij książkę na Kindle", 27, INK);
        hero.setTypeface(null, Typeface.BOLD);
        hero.setLineSpacing(dp(3), 1f);
        add(page, hero, 25);
        TextView subtitle = label("Wybierz plik na telefonie. Resztą zajmie się aplikacja.", 16, MUTED);
        subtitle.setLineSpacing(dp(3), 1f);
        add(page, subtitle, 7);

        // Duża karta z jasnym stanem, zamiast technicznego logu na ekranie głównym.
        stateCard = new LinearLayout(this);
        stateCard.setOrientation(LinearLayout.VERTICAL);
        stateCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        stateCard.setBackground(rounded(Color.WHITE, 19, BORDER));
        stateCard.setElevation(dp(2));
        add(page, stateCard, 24);
        LinearLayout stateHeader = new LinearLayout(this);
        stateHeader.setOrientation(LinearLayout.HORIZONTAL);
        stateHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
        stateIcon = label("↗", 29, GREEN);
        stateIcon.setGravity(android.view.Gravity.CENTER);
        stateIcon.setContentDescription("Gotowe");
        stateIcon.setBackground(rounded(0xffe3f5e7, 99, 0));
        stateHeader.addView(stateIcon, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout stateTexts = new LinearLayout(this);
        stateTexts.setOrientation(LinearLayout.VERTICAL);
        stateTexts.setPadding(dp(13), 0, 0, 0);
        stateTitle = label("Wszystko gotowe", 19, INK);
        stateTitle.setTypeface(null, Typeface.BOLD);
        stateTexts.addView(stateTitle);
        progressLabel = label("Czekam na książkę", 13, MUTED);
        stateTexts.addView(progressLabel);
        stateHeader.addView(stateTexts, new LinearLayout.LayoutParams(0, -2, 1));
        add(stateCard, stateHeader, 0);
        status = label("Połącz Kindle z Wi-Fi i wybierz książkę do wysłania.", 15, INK);
        status.setLineSpacing(dp(3), 1f);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        add(stateCard, status, 13);
        confirmedRows = new LinearLayout(this);
        confirmedRows.setOrientation(LinearLayout.VERTICAL);
        add(stateCard, confirmedRows, 8);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(ColorStateList.valueOf(GREEN));
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(GREEN));
        progress.setVisibility(View.GONE);
        add(stateCard, progress, 13);
        detailsButton = secondaryButton("Zobacz szczegóły");
        detailsButton.setVisibility(View.GONE);
        detailsButton.setOnClickListener(v -> showDetails());
        add(stateCard, detailsButton, 6);

        LinearLayout connection = new LinearLayout(this);
        connection.setOrientation(LinearLayout.VERTICAL);
        connection.setPadding(dp(18), dp(18), dp(18), dp(18));
        connection.setBackground(rounded(Color.WHITE, 19, BORDER));
        add(page, connection, 16);
        TextView connectionTitle = label("Połączenie z Kindle", 18, INK);
        connectionTitle.setTypeface(null, Typeface.BOLD);
        add(connection, connectionTitle, 0);
        add(connection, label("Adres zapiszę na przyszłość.", 14, MUTED), 5);
        address = new EditText(this);
        address.setId(View.generateViewId());
        connectionTitle.setLabelFor(address.getId());
        address.setTextColor(INK);
        address.setTextSize(17);
        address.setSingleLine(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setText(settings.getString("address", ""));
        address.setSelectAllOnFocus(true);
        address.setHint("Adres Kindle, np. 192.168.1.25");
        address.setBackgroundTintList(ColorStateList.valueOf(BORDER));
        add(connection, address, 8);
        TextView hint = label("Gdzie znajdę ten adres?", 14, GREEN);
        hint.setPadding(0, dp(7), 0, dp(7));
        hint.setOnClickListener(v -> helpConnection());
        hint.setContentDescription("Pomoc: jak znaleźć adres Kindle");
        add(connection, hint, 8);

        choose = primaryButton("Wybierz książkę");
        choose.setOnClickListener(v -> {
            if (sharedFiles.isEmpty()) pickFile();
            else prepareBatch(new java.util.ArrayList<>(sharedFiles));
        });
        add(page, choose, 17);
        add(page, label("EPUB · PDF · MOBI · AZW3 · TXT i inne", 13, MUTED), 7);

        cancelButton = secondaryButton("Przerwij");
        cancelButton.setVisibility(View.GONE);
        cancelButton.setOnClickListener(v -> {
            cancellationRequested = true;
            Thread worker = transferThread;
            if (worker != null) worker.interrupt();
            cancelButton.setEnabled(false);
            stateTitle.setText("Zatrzymuję wysyłanie…");
            status.setText("Zaraz wrócisz do swojej biblioteki.");
        });
        add(page, cancelButton, 8);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        list = secondaryButton("📖  Moje książki");
        list.setOnClickListener(v -> {
            if (sending) return;
            final String host = address.getText().toString().trim();
            if (!privateAddress(host)) { address.setError("Wpisz adres wyświetlony w KOReaderze."); return; }
            settings.edit().putString("address", host).apply();
            busy(true);
            stateTitle.setText("Otwieram bibliotekę…");
            status.setText("Łączę się z Twoim Kindle.");
            progress.setVisibility(View.GONE);
            new FileManager(this, () -> connect(host), () -> { busy(false); updateChoose(); resetIdle(); }).show();
        });
        actions.addView(list, new LinearLayout.LayoutParams(0, dp(53), 1));
        history = secondaryButton("Ostatnio wysłane");
        history.setOnClickListener(v -> showHistory());
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, dp(53), 1);
        hp.leftMargin = dp(9);
        actions.addView(history, hp);
        add(page, actions, 14);
        TextView tutorial = label("Pierwsze połączenie? Zobacz krótką instrukcję", 14, GREEN);
        tutorial.setGravity(android.view.Gravity.CENTER);
        tutorial.setPadding(dp(8), dp(12), dp(8), dp(12));
        tutorial.setOnClickListener(v -> helpConnection());
        add(page, tutorial, 13);

        page.setFocusableInTouchMode(true);
        page.requestFocus();
        lastDetails = settings.getString("lastResult", "");
        if (state != null) {
            java.util.ArrayList<Uri> saved = state.getParcelableArrayList("sharedFiles");
            if (saved != null) sharedFiles.addAll(saved);
            updateChoose();
        } else receiveShare(getIntent());
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putString("pendingAddress", pendingAddress);
        state.putParcelableArrayList("sharedFiles", sharedFiles);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (stroke != 0) drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private Button primaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(17);
        button.setTypeface(null, Typeface.BOLD);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(ColorStateList.valueOf(GREEN));
        button.setMinHeight(dp(58));
        button.setElevation(dp(2));
        return button;
    }

    private Button secondaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTextColor(GREEN);
        button.setBackgroundTintList(ColorStateList.valueOf(0xffe5f0e8));
        button.setMinHeight(dp(48));
        return button;
    }

    private void helpConnection() {
        new AlertDialog.Builder(this)
                .setTitle("Jak połączyć Kindle?")
                .setMessage("1. Połącz telefon i Kindle z tą samą siecią Wi-Fi.\n\n"
                        + "2. Na Kindle otwórz KOReader i włącz serwer SSH.\n\n"
                        + "3. Przepisz adres wyświetlany przez KOReader do pola «Adres Kindle».\n\n"
                        + "4. Wróć tutaj i wybierz książkę.\n\n"
                        + "Dla bezpieczeństwa wyłącz serwer na Kindle po przesłaniu książek.")
                .setPositiveButton("Rozumiem", null).show();
    }

    private void renderConfirmed(java.util.ArrayList<String> names) {
        confirmedRows.removeAllViews();
        int limit = Math.min(names.size(), 3);
        for (int i = 0; i < limit; i++) {
            TextView item = label("✓  " + names.get(i), 14, SUCCESS);
            item.setSingleLine(true);
            item.setEllipsize(android.text.TextUtils.TruncateAt.END);
            item.setTypeface(null, Typeface.BOLD);
            item.setPadding(dp(4), dp(4), dp(4), dp(4));
            confirmedRows.addView(item);
            item.setAlpha(0f);
            item.setTranslationY(dp(8));
            item.animate().alpha(1f).translationY(0f).setDuration(330)
                    .setStartDelay(i * 140L).start();
        }
        if (names.size() > limit) {
            add(confirmedRows, label("I jeszcze " + (names.size() - limit) + " książek ✓", 13, GREEN), 4);
        }
    }

    private void showDetails() {
        TextView content = label(lastDetails.isEmpty() ? "Brak dodatkowych informacji." : lastDetails, 15, INK);
        content.setTextIsSelectable(true);
        content.setPadding(dp(18), dp(15), dp(18), dp(15));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Szczegóły przesyłki")
                .setView(scroll).setPositiveButton("Zamknij", null).show();
    }

    private void resetIdle() {
        confirmedRows.removeAllViews();
        stateTitle.setText("Wszystko gotowe");
        stateIcon.setText("↗");
        stateIcon.setTextColor(GREEN);
        stateIcon.setBackground(rounded(0xffe3f5e7, 99, 0));
        stateIcon.setContentDescription("Gotowe");
        progressLabel.setText("Czekam na książkę");
        if (!sending) status.setText("Wybierz plik, który chcesz przeczytać na Kindle.");
    }

    private void showWorking(String headline, String description) {
        stateTitle.setText(headline);
        stateIcon.animate().cancel();
        stateIcon.setText("⋯");
        stateIcon.setTextColor(GREEN);
        stateIcon.setBackground(rounded(0xffe3f5e7, 99, 0));
        stateIcon.setContentDescription("Trwa przesyłanie");
        status.setText(description);
        detailsButton.setVisibility(View.GONE);
    }

    private void showSuccess(String heading, String detail) {
        stateTitle.setText(heading);
        status.setText(detail);
        stateIcon.animate().cancel();
        stateIcon.setText("✓");
        stateIcon.setTextColor(SUCCESS);
        stateIcon.setBackground(rounded(0xffdcf5e3, 99, 0));
        stateIcon.setContentDescription("Sukces, potwierdzone przesłanie");
        // Krótki sprężysty ruch zielonego ptaszka tylko PO potwierdzonym zapisie.
        stateIcon.setAlpha(0f);
        stateIcon.setScaleX(0.45f);
        stateIcon.setScaleY(0.45f);
        stateIcon.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setInterpolator(new OvershootInterpolator(2.4f)).setDuration(650).start();
        stateCard.setBackground(rounded(0xfff5fff7, 19, 0xffb2e3c0));
        stateCard.postDelayed(() -> stateCard.setBackground(rounded(Color.WHITE, 19, BORDER)), 1100);
        status.announceForAccessibility(heading + ". " + detail);
    }

    private void showNotComplete(boolean stopped, int success, int partial, int all) {
        stateTitle.setText(stopped ? "Przesyłanie przerwane" : "Nie wszystko się udało");
        stateIcon.animate().cancel();
        stateIcon.setAlpha(1f);
        stateIcon.setScaleX(1f);
        stateIcon.setScaleY(1f);
        stateIcon.setText("!");
        stateIcon.setTextColor(0xff98620e);
        stateIcon.setBackground(rounded(0xfffff1d7, 99, 0));
        stateIcon.setContentDescription("Przesyłka niekompletna");
        status.setText("Na Kindle dotarło w pełni " + success + " z " + all + " książek."
                + (partial > 0 ? " Część plików przesłano." : "")
                + " Sprawdź szczegóły przed ponowieniem próby.");
    }

    private void add(LinearLayout layout, View child, int margin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(margin);
        layout.addView(child, params);
    }

    private void pickFile() {
        if (sending) return;
        String host = address.getText().toString().trim();
        if (privateAddress(host)) settings.edit().putString("address", host).apply();
        pendingAddress = host;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(intent, PICK_FILE);
        } catch (android.content.ActivityNotFoundException e) {
            status.setText("Na telefonie brakuje systemowej aplikacji do wyboru plików.");
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILE || result != RESULT_OK || data == null || sending) return;
        java.util.ArrayList<Uri> picked = collectFiles(data, false);
        if (!privateAddress(address.getText().toString().trim())) {
            for (Uri file : picked) if (!sharedFiles.contains(file)) sharedFiles.add(file);
            updateChoose();
            status.setText("Książki wybrane. Wpisz adres Kindle i dotknij „Wyślij książki”.");
            address.setError("Tutaj wpisz adres Kindle pokazany w KOReaderze.");
        } else prepareBatch(picked);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        receiveShare(intent);
    }

    private java.util.ArrayList<Uri> collectFiles(Intent intent, boolean share) {
        java.util.LinkedHashSet<Uri> files = new java.util.LinkedHashSet<>();
        if (share && Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())) {
            java.util.ArrayList<Uri> streams = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (streams != null) files.addAll(streams);
        } else if (share) {
            Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream != null) files.add(stream);
        } else if (intent.getData() != null) files.add(intent.getData());
        if (intent.getClipData() != null) {
            for (int i = 0; i < intent.getClipData().getItemCount(); i++) {
                Uri uri = intent.getClipData().getItemAt(i).getUri();
                if (uri != null) files.add(uri);
            }
        }
        java.util.ArrayList<Uri> safe = new java.util.ArrayList<>();
        for (Uri uri : files) {
            if (uri != null && "content".equals(uri.getScheme())) safe.add(uri);
        }
        return safe;
    }

    private void receiveShare(Intent intent) {
        if (intent == null || !(Intent.ACTION_SEND.equals(intent.getAction())
                || Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction()))) return;
        java.util.ArrayList<Uri> incoming = collectFiles(intent, true);
        for (Uri uri : incoming) if (!sharedFiles.contains(uri)) sharedFiles.add(uri);
        updateChoose();
        if (!sending) {
            resetIdle();
            if (!sharedFiles.isEmpty()) status.setText("Wybrano " + sharedFiles.size() + " książek. Dotknij przycisku, aby je wysłać.");
        }
        else android.widget.Toast.makeText(this, "Dodano książki do następnej przesyłki.", android.widget.Toast.LENGTH_LONG).show();
    }

    private void updateChoose() {
        choose.setText(sharedFiles.isEmpty() ? "Wybierz książki"
                : "Wyślij książki (" + sharedFiles.size() + ")");
    }

    private void busy(boolean value) {
        sending = value;
        address.setEnabled(!value);
        choose.setEnabled(!value);
        list.setEnabled(!value);
        progress.setVisibility(value ? View.VISIBLE : View.GONE);
        if (value) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void prepareBatch(java.util.ArrayList<Uri> files) {
        if (sending || files.isEmpty()) return;
        boolean pdf = false;
        int pdfCount = 0;
        for (Uri uri : files) if (displayName(uri).toLowerCase(Locale.ROOT).endsWith(".pdf")) { pdf = true; pdfCount++; }
        if (!pdf) { pdfOptions = null; pdfMode = 0; startBatch(files); return; }
        final int numberPdf = pdfCount;
        final Uri previewUri = firstPdf(files);
        ScrollView scroll = new ScrollView(this);
        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.VERTICAL);
        fields.setPadding(dp(16),dp(8),dp(16),dp(8));
        scroll.addView(fields);
        add(fields,label("Wybierz format, w którym chcesz czytać na Kindle. Oryginalny PDF zostanie na telefonie.",16,INK),0);
        RadioGroup modes = new RadioGroup(this);
        String[] labels = {"Zachowaj PDF", "Zamień na wygodniejszy EPUB", "Wyślij oba formaty (polecane)"};
        for (int i=0;i<3;i++) {
            RadioButton radio = new RadioButton(this);
            radio.setText(labels[i]); radio.setId(4000+i);
            modes.addView(radio);
        }
        modes.check(4002);
        add(fields,modes,8);
        TextView more = label("⚙  Dodatkowe ustawienia książki  ▾", 15, GREEN);
        more.setPadding(0, dp(14), 0, dp(10));
        add(fields, more, 8);
        LinearLayout advanced = new LinearLayout(this);
        advanced.setOrientation(LinearLayout.VERTICAL);
        advanced.setVisibility(View.GONE);
        add(fields, advanced, 0);
        more.setOnClickListener(v -> {
            boolean opening = advanced.getVisibility() != View.VISIBLE;
            advanced.setVisibility(opening ? View.VISIBLE : View.GONE);
            more.setText(opening ? "⚙  Ukryj ustawienia  ▴" : "⚙  Dodatkowe ustawienia książki  ▾");
        });
        EditText title = field(advanced, "Tytuł (pusty = nazwa PDF)", numberPdf==1 ? stem(displayName(previewUri)) : "");
        EditText author = field(advanced, "Autor (opcjonalnie)", "");
        EditText language = field(advanced, "Język (np. pl, de, en)", "pl");
        EditText first = field(advanced, "Pierwsza strona", "1");
        first.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText last = field(advanced, "Ostatnia strona (puste = koniec)", "");
        last.setInputType(InputType.TYPE_CLASS_NUMBER);
        CheckBox hyphens = new CheckBox(this); hyphens.setText("Łącz wyrazy dzielone na końcu linii"); hyphens.setChecked(true); add(advanced,hyphens,4);
        CheckBox numbers = new CheckBox(this); numbers.setText("Usuń samodzielne numery stron"); numbers.setChecked(true); add(advanced,numbers,0);
        CheckBox images = new CheckBox(this); images.setText("Dodaj osadzone ilustracje (większy EPUB)"); images.setChecked(false); add(advanced,images,0);
        CheckBox ocr = new CheckBox(this); ocr.setText("OCR skanowanych stron automatycznie (offline)"); ocr.setChecked(true); add(advanced,ocr,4);
        CheckBox forceOcr = new CheckBox(this); forceOcr.setText("Dokładny odczyt wszystkich stron (wolniej)"); forceOcr.setChecked(true); add(advanced,forceOcr,0);
        add(advanced,label("OCR działa bez internetu, ale skany niewyraźne, układy wielokolumnowe i tabele mogą wymagać poprawek.",13,INK),8);
        Button preview = secondaryButton("Podgląd tekstu książki"); add(advanced,preview,8);
        preview.setOnClickListener(v -> {
            PdfEpubConverter.Options opts;
            try { opts = getPdfOptions(title,author,language,first,last,hyphens,numbers,images,ocr,forceOcr); }
            catch (Exception e) { new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("OK",null).show(); return; }
            preview.setEnabled(false);
            new Thread(() -> {
                File pdfCopy = null; String result;
                try { pdfCopy = cachePdf(previewUri); result = PdfEpubConverter.preview(this,pdfCopy,opts); }
                catch (Exception error) { result = "Nie można przygotować podglądu: " + userMessage(error); }
                finally { if (pdfCopy != null) pdfCopy.delete(); }
                final String shown = result;
                runOnUiThread(() -> {preview.setEnabled(true); TextView view=label(shown,15,INK);view.setPadding(dp(16),dp(12),dp(16),dp(12));view.setTextIsSelectable(true);ScrollView box=new ScrollView(this);box.addView(view);new AlertDialog.Builder(this).setTitle("Podgląd konwersji").setView(box).setPositiveButton("Zamknij",null).show();});
            },"pdf-preview").start();
        });
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Jak wysłać tę książkę?")
            .setView(scroll).setNegativeButton("Anuluj",null)
            .setPositiveButton("Kontynuuj",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                int mode = modes.getCheckedRadioButtonId()-4000;
                if(mode<0 || mode>2) throw new IOException("Wybierz format przesyłki.");
                PdfEpubConverter.Options opts = mode == 0 ? null : getPdfOptions(title,author,language,first,last,hyphens,numbers,images,ocr,forceOcr);
                pdfMode = mode; pdfOptions = opts;
                if (!preview.isEnabled()) { android.widget.Toast.makeText(this, "Poczekaj na zakończenie podglądu.", android.widget.Toast.LENGTH_SHORT).show(); return; }
                dialog.dismiss(); startBatch(files);
            } catch(Exception error) { new AlertDialog.Builder(this).setMessage(error.getMessage()).setPositiveButton("OK",null).show(); }
        }));
        dialog.show();
    }

    private Uri firstPdf(java.util.ArrayList<Uri> files) {
        for(Uri uri:files) if(displayName(uri).toLowerCase(Locale.ROOT).endsWith(".pdf")) return uri;
        return files.get(0);
    }

    private EditText field(LinearLayout parent, String label, String defaultValue) {
        add(parent, label(label,13,INK),9);
        EditText edit = new EditText(this); edit.setSingleLine(true); edit.setText(defaultValue);
        add(parent,edit,0); return edit;
    }
    private static String stem(String name) { int dot=name.lastIndexOf('.'); return dot>0?name.substring(0,dot):name; }
    private static int numeric(EditText field, int fallback) throws IOException {
        String s=field.getText().toString().trim();
        if(s.isEmpty()) return fallback;
        try { return Integer.parseInt(s); } catch(NumberFormatException e) { throw new IOException("Nieprawidłowy zakres stron."); }
    }
    private PdfEpubConverter.Options getPdfOptions(EditText title,EditText author,EditText language,
            EditText first,EditText last,CheckBox hyphens,CheckBox numbers,CheckBox images,CheckBox ocr,CheckBox forceOcr) throws IOException {
        PdfEpubConverter.Options o=new PdfEpubConverter.Options();
        o.title=title.getText().toString().trim(); o.author=author.getText().toString().trim();
        o.language=language.getText().toString().trim();
        if(!o.language.matches("[a-zA-Z]{2,3}(-[a-zA-Z]{2,4})?")) throw new IOException("Język wpisz jako pl, de lub en.");
        o.firstPage=numeric(first,1); o.lastPage=numeric(last,0);
        if(o.firstPage<1 || (o.lastPage!=0 && o.lastPage<o.firstPage)) throw new IOException("Nieprawidłowy zakres stron.");
        o.joinHyphens=hyphens.isChecked(); o.removePageNumbers=numbers.isChecked(); o.includeImages=images.isChecked();
        o.ocrScans=ocr.isChecked(); o.forceOcr=forceOcr.isChecked();
        return o;
    }
    private File cachePdf(Uri uri) throws IOException {
        File copy=File.createTempFile("pdf-source-",".pdf",getCacheDir());
        try (InputStream in=getContentResolver().openInputStream(uri); java.io.OutputStream out=new java.io.FileOutputStream(copy)) {
            if (in==null) throw new IOException("Nie można odczytać PDF.");
            byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1) {
                if (Thread.currentThread().isInterrupted() || cancellationRequested)
                    throw new java.io.InterruptedIOException("Przerwano odczyt książki.");
                out.write(buffer,0,n);
            }
        } catch(IOException e) { copy.delete(); throw e; }
        if(copy.length()==0) { copy.delete(); throw new IOException("PDF jest pusty."); }
        return copy;
    }
    /** Each part of a two-format transfer is reported separately, including partial success. */
    private static final class SendOutcome {
        private final StringBuilder details = new StringBuilder();
        boolean complete = true;
        boolean anyOnKindle;
        void saved(String description, String location) {
            details.append("✓ ").append(description).append(": ").append(location).append('\n');
        }
        void failed(String description, Exception problem) {
            complete = false;
            details.append("✗ ").append(description).append(": ")
                    .append(userMessage(problem)).append('\n');
        }
        @Override public String toString() { return details.toString().trim(); }
    }

    private SendOutcome convertAndSend(String host, Uri uri, boolean sendPdf) throws Exception {
        SendOutcome outcome = new SendOutcome();
        File cached = cachePdf(uri);
        File epub = File.createTempFile("kindle-converted-", ".epub", getCacheDir());
        epub.delete();
        try {
            String base = stem(displayName(uri));
            String epubName = base + ".epub";
            if (sendPdf) {
                checkCancelled();
                runOnUiThread(() -> status.setText("Wysyłam PDF…"));
                try {
                    outcome.saved("PDF na Kindle", uploadFile(host, cached, displayName(uri)));
                    outcome.anyOnKindle = true;
                } catch (Exception e) {
                    if (Thread.currentThread().isInterrupted() || cancellationRequested) throw e;
                    outcome.failed("PDF na Kindle", e);
                }
            }
            checkCancelled();
            runOnUiThread(() -> { progress.setIndeterminate(true);status.setText("Przygotowuję wygodną wersję do czytania…"); });
            PdfEpubConverter.Options current = new PdfEpubConverter.Options();
            current.title = pdfOptions.title; current.author = pdfOptions.author; current.language = pdfOptions.language;
            current.firstPage = pdfOptions.firstPage; current.lastPage = pdfOptions.lastPage;
            current.joinHyphens = pdfOptions.joinHyphens; current.removePageNumbers = pdfOptions.removePageNumbers;
            current.includeImages = pdfOptions.includeImages; current.ocrScans = pdfOptions.ocrScans;
            current.forceOcr = pdfOptions.forceOcr;
            // A custom title applies to one PDF only. Every file keeps its own filename.
            if (fileCount > 1) current.title = base;
            try {
                PdfEpubConverter.ConversionSummary summary = PdfEpubConverter.convert(this, cached, epub, current,
                        (page, total) -> runOnUiThread(() -> status.setText("Przygotowuję książkę: strona " + page + " z " + total)));
                outcome.saved("Konwersja EPUB", summary.pages + " stron");
                if (!summary.emptyPages.isEmpty())
                    outcome.saved("Uwaga: strony bez rozpoznanego tekstu", summary.emptyPages.toString());
            } catch (Exception e) {
                if (Thread.currentThread().isInterrupted() || cancellationRequested) throw e;
                outcome.failed("Konwersja EPUB", e);
                return outcome;
            }
            checkCancelled();
            try {
                saveEpub(epub, epubName);
                outcome.saved("EPUB zapisany w telefonie", "Pobrane / Kindle przez WiFi (Android 10+) lub pliki aplikacji");
            } catch (Exception e) {
                if (Thread.currentThread().isInterrupted() || cancellationRequested) throw e;
                outcome.failed("Lokalny EPUB", e);
            }
            checkCancelled();
            try {
                outcome.saved("EPUB na Kindle", uploadFile(host, epub, epubName));
                outcome.anyOnKindle = true;
            } catch (Exception e) {
                if (Thread.currentThread().isInterrupted() || cancellationRequested) throw e;
                outcome.failed("EPUB na Kindle", e);
            }
            return outcome;
        } finally { cached.delete(); epub.delete(); }
    }

    private void checkCancelled() throws InterruptedException {
        if (cancellationRequested || Thread.currentThread().isInterrupted())
            throw new InterruptedException("Użytkownik przerwał operację.");
    }

    private void saveEpub(File epub, String name) throws IOException {
        if(Build.VERSION.SDK_INT >= 29) {
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
            values.put(MediaStore.MediaColumns.MIME_TYPE,"application/epub+zip");
            values.put("relative_path",Environment.DIRECTORY_DOWNLOADS+"/Kindle przez WiFi");
            Uri target=getContentResolver().insert(Uri.parse("content://media/external/downloads"),values);
            if(target==null) throw new IOException("Nie udało się zapisać EPUB w Pobranych.");
            try (InputStream in=new java.io.FileInputStream(epub);
                 java.io.OutputStream out=getContentResolver().openOutputStream(target)) {
                if(out==null) throw new IOException("Nie można zapisać EPUB w Pobranych.");
                byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1) {
                    if (Thread.currentThread().isInterrupted() || cancellationRequested)
                        throw new java.io.InterruptedIOException("Przerwano zapis EPUB.");
                    out.write(bytes,0,n);
                }
            } catch(IOException e) {getContentResolver().delete(target,null,null);throw e;}
        } else {
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"EPUB");
            if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Brak folderu na EPUB.");
            File dest=new File(dir,name);
            int i=2;while(dest.exists())dest=new File(dir,stem(name)+" ("+(i++)+").epub");
            try(InputStream in=new java.io.FileInputStream(epub);java.io.OutputStream out=new java.io.FileOutputStream(dest)){
                byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1) {
                    if (Thread.currentThread().isInterrupted() || cancellationRequested)
                        throw new java.io.InterruptedIOException("Przerwano zapis EPUB.");
                    out.write(bytes,0,n);
                }
            }
        }
    }

    private void startBatch(java.util.ArrayList<Uri> files) {
        if (sending || files.isEmpty()) return;
        final String host = address.getText().toString().trim();
        if (!privateAddress(host)) { address.setError("Wpisz adres IPv4 z KOReadera."); return; }
        settings.edit().putString("address", host).apply();
        sharedFiles.removeAll(files);
        updateChoose();
        cancellationRequested = false;
        busy(true);
        cancelButton.setEnabled(true);
        cancelButton.setVisibility(View.VISIBLE);
        status.setText("Przygotowuję przesyłkę…");
        stateCard.setBackground(rounded(Color.WHITE, 19, BORDER));
        confirmedRows.removeAllViews();
        showWorking("Wysyłam Twoje książki", "Przygotowuję przesyłkę…");
        progressLabel.setText("Trwa przesyłanie");
        transferThread = new Thread(() -> {
            int ok = 0;
            int partial = 0;
            int attempted = 0;
            java.util.ArrayList<String> confirmed = new java.util.ArrayList<>();
            StringBuilder report = new StringBuilder();
            fileCount = files.size();
            try {
                for (int i = 0; i < files.size(); i++) {
                    if (cancellationRequested || Thread.currentThread().isInterrupted()) break;
                    currentFile = i + 1;
                    Uri uri = files.get(i);
                    String name = "Książka " + currentFile;
                    String id = java.util.UUID.randomUUID().toString();
                    attempted++;
                    try {
                        name = displayName(uri);
                        record(id, name, host, "W trakcie / jeszcze niepotwierdzona", "");
                        final String shownName = name;
                        final int index = currentFile, total = fileCount;
                        runOnUiThread(() -> {
                            progress.setIndeterminate(true);
                            progressLabel.setText("Książka " + index + " z " + total);
                            status.setText("Teraz: " + shownName);
                        });
                        boolean pdf = name.toLowerCase(Locale.ROOT).endsWith(".pdf");
                        if (pdf && pdfMode != 0 && pdfOptions != null) {
                            SendOutcome outcome = convertAndSend(host, uri, pdfMode == 2);
                            String result = outcome.toString();
                            record(id, name, host, outcome.complete ? "Zapisano i sprawdzono" : "Częściowo wykonano", result);
                            if (outcome.complete && outcome.anyOnKindle) { ok++; confirmed.add(name); }
                            else if (outcome.anyOnKindle) partial++;
                            report.append(result).append('\n');
                        } else {
                            String path = send(host, uri);
                            record(id, name, host, "Zapisano i sprawdzono", path);
                            ok++;
                            confirmed.add(name);
                            report.append("✓ ").append(path).append('\n');
                        }
                    } catch (Exception error) {
                        if (cancellationRequested || Thread.currentThread().isInterrupted() || error instanceof InterruptedException) {
                            record(id, name, host, "Przerwano przez użytkownika", "Wysyłka tej książki nie została potwierdzona.");
                            report.append("■ Przerwano: ").append(name).append('\n');
                            cancellationRequested = true;
                            break;
                        }
                        String detail = userMessage(error);
                        record(id, name, host, "Niepotwierdzona", detail);
                        report.append("✗ ").append(name).append(": ").append(detail).append('\n');
                    }
                }
            } finally {
                boolean stopped = cancellationRequested;
                final String result = (stopped ? "Przerwano. " : "Zakończono. ")
                        + "W pełni wysłane: " + ok + " z " + files.size()
                        + (partial > 0 ? ", częściowo: " + partial : "")
                        + (attempted < files.size() ? ", pominięte: " + (files.size() - attempted) : "")
                        + "\n\n" + report + "\nW KOReaderze otwórz documents. Wyjdź z folderu i wejdź ponownie, aby odświeżyć listę.";
                settings.edit().putString("lastResult", result).apply();
                transferThread = null;
                final int sentOk = ok;
                final int sentPartial = partial;
                final java.util.ArrayList<String> confirmedOnKindle = new java.util.ArrayList<>(confirmed);
                runOnUiThread(() -> {
                    busy(false);
                    cancelButton.setVisibility(View.GONE);
                    progressLabel.setText(stopped ? "Przerwano" : "Przesyłka zakończona");
                    lastDetails = result;
                    detailsButton.setVisibility(View.VISIBLE);
                    renderConfirmed(confirmedOnKindle);
                    if (!stopped && sentOk == files.size() && sentPartial == 0) {
                        showSuccess(files.size() == 1 ? "Książka jest na Kindle!" : "Książki są na Kindle!", files.size() == 1
                                ? "Książka została przesłana i sprawdzona. Możesz zacząć czytać."
                                : "Przesłano i sprawdzono wszystkie książki: " + files.size() + ". Miłego czytania!");
                    } else {
                        showNotComplete(stopped, sentOk, sentPartial, files.size());
                    }
                    updateChoose();
                });
            }
        }, "kindle-batch");
        transferThread.start();
    }

    private synchronized void record(String id, String name, String host, String result, String detail) {
        try {
            org.json.JSONArray old = new org.json.JSONArray(settings.getString("history", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            org.json.JSONObject item = new org.json.JSONObject();
            item.put("id", id); item.put("name", name); item.put("host", host);
            item.put("time", System.currentTimeMillis()); item.put("result", result); item.put("detail", detail);
            next.put(item);
            for (int i = 0; i < old.length() && next.length() < 100; i++) {
                org.json.JSONObject existing = old.getJSONObject(i);
                if (!id.equals(existing.optString("id"))) next.put(existing);
            }
            settings.edit().putString("history", next.toString()).commit();
        } catch (org.json.JSONException ignored) { }
    }

    private void showHistory() {
        StringBuilder text = new StringBuilder();
        try {
            org.json.JSONArray items = new org.json.JSONArray(settings.getString("history", "[]"));
            java.text.DateFormat date = new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
            for (int i = 0; i < items.length(); i++) {
                org.json.JSONObject item = items.getJSONObject(i);
                text.append(date.format(new java.util.Date(item.getLong("time")))).append(" • ")
                    .append(item.optString("name")).append('\n').append(item.optString("result"))
                    .append(" • ").append(item.optString("host")).append('\n')
                    .append(item.optString("detail")).append("\n\n");
            }
        } catch (org.json.JSONException e) { text.append("Nie można odczytać historii."); }
        if (text.length() == 0) text.append("Historia nowych przesyłek pojawi się tutaj.");
        TextView content = label(text.toString(), 16, INK);
        content.setPadding(dp(20), dp(12), dp(20), dp(12));
        content.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Ostatnio wysłane")
                .setView(scroll).setPositiveButton("Zamknij", null).show();
    }

    @Override public void onBackPressed() {
        if (sending) android.widget.Toast.makeText(this, "Poczekaj na zakończenie przesyłania.", android.widget.Toast.LENGTH_SHORT).show();
        else super.onBackPressed();
    }

    private static boolean privateAddress(String host) {
        if (host == null || !host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        String[] parts = host.split("\\.");
        int[] octet = new int[4];
        for (int i = 0; i < 4; i++) {
            octet[i] = Integer.parseInt(parts[i]);
            if (octet[i] > 255 || !Integer.toString(octet[i]).equals(parts[i])) return false;
        }
        return octet[0] == 10 || (octet[0] == 172 && octet[1] >= 16 && octet[1] <= 31)
                || (octet[0] == 192 && octet[1] == 168);
    }

    private Session connect(String host) throws Exception {
        JSch ssh = new JSch();
        File knownHosts = new File(getFilesDir(), "known_hosts");
        if (!knownHosts.exists()) knownHosts.createNewFile();
        ssh.setKnownHosts(knownHosts.getPath());
        Session session = ssh.getSession("root", host, 2222);
        session.setPassword("root");
        session.setConfig("StrictHostKeyChecking", "ask");
        session.setConfig("PreferredAuthentications", "password,keyboard-interactive");
        String hostKeys = session.getConfig("server_host_key");
        if (!java.util.Arrays.asList(hostKeys.split(",")).contains("ssh-rsa")) {
            session.setConfig("server_host_key", hostKeys + ",ssh-rsa");
        }
        session.setUserInfo(new UserInfo() {
            public String getPassphrase() { return null; }
            public String getPassword() { return "root"; }
            public boolean promptPassword(String message) { return false; }
            public boolean promptPassphrase(String message) { return false; }
            public void showMessage(String message) { }
            public boolean promptYesNo(String message) {
                if (message == null || !message.contains("authenticity") || !message.contains("fingerprint")) {
                    return false;
                }
                return confirmHost(host, message);
            }
        });

        try {
            session.connect(12000);
            session.setTimeout(30000);
            return session;
        } catch (Exception e) { session.disconnect(); throw e; }
    }

    private String send(String host, Uri file) throws Exception {
        File cached = File.createTempFile("upload-", ".tmp", getCacheDir());
        try {
            String name = displayName(file);
            String lower = name.toLowerCase(Locale.ROOT);
            if (!(lower.endsWith(".epub") || lower.endsWith(".pdf") || lower.endsWith(".mobi")
                    || lower.endsWith(".azw") || lower.endsWith(".azw3") || lower.endsWith(".fb2")
                    || lower.endsWith(".txt") || lower.endsWith(".djvu") || lower.endsWith(".cbz"))) {
                throw new IOException("Wybierz książkę, np. plik z końcówką .epub lub .pdf.");
            }
            try (InputStream in = getContentResolver().openInputStream(file);
                 java.io.OutputStream out = new java.io.FileOutputStream(cached)) {
                if (in == null) throw new IOException("Nie można otworzyć pliku na telefonie.");
                byte[] buffer = new byte[32768];
                int count;
                while ((count = in.read(buffer)) != -1) {
                    if (Thread.currentThread().isInterrupted() || cancellationRequested)
                        throw new java.io.InterruptedIOException("Przerwano przygotowywanie książki.");
                    out.write(buffer, 0, count);
                }
            }
            if (lower.endsWith(".epub")) {
                try (java.util.zip.ZipFile epub = new java.util.zip.ZipFile(cached)) {
                    if (epub.getEntry("META-INF/container.xml") == null)
                        throw new IOException("Ten plik nie zawiera struktury książki EPUB.");
                }
            }
            return uploadFile(host,cached,name);
        } finally { cached.delete(); }
    }

    private String uploadFile(String host, File source, String name) throws Exception {
        Session session=null;
        ChannelSftp channel=null;
        try {
            session=connect(host);
            channel=(ChannelSftp)session.openChannel("sftp");
            channel.connect(12000);
            if(!channel.stat("/mnt/us/koreader").isDir())
                throw new IOException("Pod tym adresem nie znaleziono folderu KOReadera.");
            return VerifiedTransfer.upload(channel,source,name,DESTINATION,
                text -> runOnUiThread(() -> status.setText(text.contains("Sprawdzam")
                        ? "Jeszcze chwila: sprawdzam książkę na Kindle…"
                        : "Przesyłam książkę do Kindle…")),
                percent -> {
                    final int index = currentFile, total = fileCount;
                    runOnUiThread(() -> {
                        progress.setIndeterminate(false);
                        progress.setProgress(percent);
                        progressLabel.setText("Książka " + index + " z " + total + " • " + percent + "%");
                    });
                });
        } finally {
            if(channel!=null)channel.disconnect();
            if(session!=null)session.disconnect();
        }
    }

    private void showRemoteFiles() {
        if (sending) return;
        final String host = address.getText().toString().trim();
        if (!privateAddress(host)) {
            address.setError("Wpisz lokalny adres IPv4 pokazany przez KOReader.");
            return;
        }
        settings.edit().putString("address", host).apply();
        sending = true;
        address.setEnabled(false);
        choose.setEnabled(false);
        list.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        progressLabel.setText("");
        status.setText("Odczytuję pliki bezpośrednio z Kindle…");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        new Thread(() -> {
            Session session = null;
            ChannelSftp channel = null;
            String message;
            try {
                session = connect(host);
                channel = (ChannelSftp) session.openChannel("sftp");
                channel.connect(12000);
                message = "Pliki na Kindle (" + host + "):\n\n"
                        + VerifiedTransfer.list(channel, DESTINATION);
                try { message += "\nStarsze przesyłki:\n" + VerifiedTransfer.list(channel, "/mnt/us/Books"); }
                catch (SftpException e) {
                    if (e.id != ChannelSftp.SSH_FX_NO_SUCH_FILE) throw e;
                }
            } catch (Exception error) {
                message = userMessage(error);
            } finally {
                if (channel != null) channel.disconnect();
                if (session != null) session.disconnect();
            }
            final String result = message;
            runOnUiThread(() -> {
                sending = false;
                address.setEnabled(true);
                choose.setEnabled(true);
                list.setEnabled(true);
                progress.setVisibility(View.GONE);
                status.setText(result);
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }, "kindle-list").start();
    }

    private boolean confirmHost(String host, String fingerprint) {
        AtomicBoolean accepted = new AtomicBoolean();
        CountDownLatch latch = new CountDownLatch(1);
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) {
                latch.countDown();
                return;
            }
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Połączyć z Kindle’em?")
                    .setMessage("Adres czytnika: " + host + "\n\nPorównaj tożsamość serwera przed pierwszym połączeniem.\n\n" + fingerprint)
                    .setPositiveButton("Połącz", (d, which) -> accepted.set(true))
                    .setNegativeButton("Anuluj", (d, which) -> {})
                    .create();
            dialog.setOnDismissListener(d -> latch.countDown());
            dialog.show();
            new android.os.Handler(getMainLooper()).postDelayed(() -> {
                if (dialog.isShowing()) dialog.dismiss();
            }, 60000);
        });
        try {
            return latch.await(62, TimeUnit.SECONDS) && accepted.get();
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private String displayName(Uri file) {
        String name = "plik";
        try (Cursor cursor = getContentResolver().query(file,
                new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && cursor.getString(0) != null) {
                name = cursor.getString(0);
            }
        }
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (name.endsWith(".") || name.endsWith(" ")) name = name.substring(0, name.length() - 1);
        if (name.isEmpty()) return "plik";
        if (name.startsWith(".")) name = "plik" + name;
        int dot = name.lastIndexOf('.');
        String suffix = dot > 0 && name.length() - dot <= 20 ? name.substring(dot) : "";
        if (name.getBytes(StandardCharsets.UTF_8).length > 220) {
            String stem = name.substring(0, name.length() - suffix.length());
            while ((stem + suffix).getBytes(StandardCharsets.UTF_8).length > 220) {
                stem = stem.substring(0, stem.offsetByCodePoints(stem.length(), -1));
            }
            name = stem + suffix;
        }
        return name;
    }

    private static String userMessage(Exception error) {
        String detail = error.getMessage() == null ? "" : error.getMessage();
        if (error instanceof JSchException) {
            String lower = detail.toLowerCase(Locale.ROOT);
            if (lower.contains("reject hostkey") || lower.contains("hostkey has been changed")) {
                return "Nie potwierdzono tożsamości Kindle’a. Sprawdź adres na ekranie KOReadera.";
            }
            if (lower.contains("auth")) {
                return "Kindle odrzucił logowanie. Sprawdź ustawienia serwera SSH. Jeśli korzystasz z logowania bez hasła, używaj go tylko w zaufanej sieci domowej i wyłącz serwer po przesyłce.";
            }
            return "Nie udało się połączyć. Sprawdź adres Kindle’a, włączony serwer SSH i wspólne domowe Wi‑Fi.\n" + detail;
        }
        if (error instanceof SftpException) {
            return "Nie potwierdzono operacji na Kindle. Sprawdź folder documents i wolne miejsce.\n" + detail;
        }
        return "Zapis niepotwierdzony. " + detail;
    }
}
