package pl.ispinalokalnie.kindlewifi;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import java.io.*;
import java.security.*;
import java.util.*;

/** No Android dependencies: the exact transfer implementation is integration tested. */
public final class VerifiedTransfer {
    public interface Progress { void update(String message); }
    public interface Percent { void update(int value); }
    public static String upload(ChannelSftp channel, File local, String name,
                                String directory, Progress progress) throws Exception {
        return upload(channel, local, name, directory, progress, value -> {});
    }
    public static String upload(ChannelSftp channel, File local, String name,
                                String directory, Progress progress, Percent percent) throws Exception {
        percent.update(0);
        if (local.length() == 0) throw new IOException("Wybrany plik jest pusty.");
        if (name.startsWith(".") || name.contains("/") || name.contains("\\"))
            throw new IOException("Nieprawidłowa nazwa pliku.");
        channel.cd(directory); // Never silently fall back to an unrelated directory.
        String actual = channel.pwd();
        String target = availableName(channel, name);
        String temporary = ".kindle-upload-" + UUID.randomUUID() + ".part";
        try {
            progress.update("Przesyłam książkę do documents…");
            try (InputStream in = new FileInputStream(local)) { channel.put(in, temporary, new com.jcraft.jsch.SftpProgressMonitor() {
                private long count; private int last = -1;
                public void init(int operation, String src, String dest, long max) {}
                public boolean count(long bytes) {
                    count += bytes;
                    int value = (int)Math.min(50, count * 50 / local.length());
                    if (value != last) { last = value; percent.update(value); }
                    return !Thread.currentThread().isInterrupted();
                }
                public void end() {}
            }); }
            if (channel.lstat(temporary).getSize() != local.length())
                throw new IOException("Kindle zapisał niepełny plik. Spróbuj ponownie.");
            progress.update("Sprawdzam zawartość książki zapisanej na Kindle…");
            verify(channel, local, temporary, percent);
            if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Przerwano przesyłkę przed zatwierdzeniem pliku.");
            channel.rename(temporary, literal(target));
            temporary = null;
            percent.update(100);
            return actual + "/" + target;
        } finally {
            if (temporary != null && channel.isConnected()) {
                try { channel.rm(temporary); } catch (Exception ignored) { }
            }
        }
    }

    public static void verify(ChannelSftp channel, File local, String remote) throws Exception {
        verify(channel, local, remote, value -> {});
    }
    private static void verify(ChannelSftp channel, File local, String remote, Percent percent) throws Exception {
        if (channel.lstat(literal(remote)).getSize() != local.length())
            throw new IOException("Nie potwierdzono pełnego zapisu książki na Kindle.");
        byte[] expected;
        try (InputStream in = new FileInputStream(local)) { expected = digest(in); }
        byte[] actual;
        try (InputStream in = channel.get(literal(remote))) { MessageDigest hash = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[32768]; int n; long read = 0; int last = -1;
            while ((n = in.read(buffer)) != -1) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Przerwano weryfikację książki.");
                hash.update(buffer, 0, n); read += n;
                int value = (int)Math.min(99, 50 + read * 49 / Math.max(1, local.length()));
                if (value != last) { last = value; percent.update(value); }
            }
            actual = hash.digest(); }
        if (!MessageDigest.isEqual(expected, actual))
            throw new IOException("Plik na Kindle różni się od pliku w telefonie. Zapis niepotwierdzony.");
    }

    private static byte[] digest(InputStream in) throws Exception {
        MessageDigest hash = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[32768];
        int count;
        while ((count = in.read(buffer)) != -1) {
            if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Przerwano odczyt książki.");
            hash.update(buffer, 0, count);
        }
        return hash.digest();
    }

    public static String literal(String value) {
        return value.replace("\\", "\\\\").replace("*", "\\*").replace("?", "\\?");
    }

    private static String availableName(ChannelSftp channel, String name) throws Exception {
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i <= 999; i++) {
            String candidate = i == 1 ? name : stem + " (" + i + ")" + ext;
            try { channel.lstat(literal(candidate)); }
            catch (SftpException e) {
                if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) return candidate;
                throw e;
            }
        }
        throw new IOException("Zbyt wiele plików o tej samej nazwie.");
    }

    public static String list(ChannelSftp channel, String directory) throws Exception {
        Vector<ChannelSftp.LsEntry> files = channel.ls(directory);
        List<String> names = new ArrayList<>();
        for (ChannelSftp.LsEntry entry : files) {
            String name = entry.getFilename();
            if (!entry.getAttrs().isDir() && !name.startsWith("."))
                names.add(name + "  (" + entry.getAttrs().getSize() + " B)");
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        StringBuilder text = new StringBuilder(directory + "\n");
        if (names.isEmpty()) text.append("Brak plików.\n");
        for (String name : names) text.append(name).append('\n');
        return text.toString();
    }
}
