package pl.ispinalokalnie.kindlewifi;

import android.app.*;
import android.widget.*;
import android.view.*;
import android.text.*;
import com.jcraft.jsch.*;
import java.util.*;

public final class FileManager {
    public interface Connection { Session open() throws Exception; }
    interface Task { Object run(RemoteFiles files) throws Exception; }
    interface Done { void accept(Object result); }
    private final Activity activity;
    private final Connection connection;
    private final Runnable onClose;
    private final String[] roots={"/mnt/us/documents","/mnt/us/Books"};
    private String path=roots[0];
    private List<RemoteFiles.Entry> entries=new ArrayList<>();
    private final LinkedHashSet<String> selected=new LinkedHashSet<>();
    private LinearLayout rows;
    private EditText search;
    private TextView location, info;
    private AlertDialog dialog;
    private boolean working;
    public FileManager(Activity a,Connection c,Runnable close) {activity=a;connection=c;onClose=close;}
    private int dp(int n){return Math.round(n*activity.getResources().getDisplayMetrics().density);}
    private Button button(String text,Runnable click){Button b=new Button(activity);b.setText(text);b.setAllCaps(false);b.setOnClickListener(v->{if(!working)click.run();});return b;}
    public void show() {
        LinearLayout page=new LinearLayout(activity);page.setOrientation(1);page.setPadding(dp(16),dp(14),dp(16),dp(12));
        location=new TextView(activity);location.setTextColor(0xff19764b);
        location.setTextSize(17);location.setTypeface(null,android.graphics.Typeface.BOLD);
        location.setPadding(0,dp(6),0,dp(8));page.addView(location);
        LinearLayout nav=new LinearLayout(activity);
        nav.addView(button("Foldery",()->new AlertDialog.Builder(activity).setItems(new String[]{"documents","Books"},(d,w)->load(roots[w])).show()));
        nav.addView(button("Wstecz",()->{if(!Arrays.asList(roots).contains(path))load(path.substring(0,path.lastIndexOf('/')));}));
        nav.addView(button("Odśwież",()->load(path)));for (int i=0;i<nav.getChildCount();i++) nav.getChildAt(i).setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
        page.addView(nav);
        search=new EditText(activity);search.setSingleLine(true);search.setHint("Szukaj w tym folderze");page.addView(search);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(Editable e){}});
        info=new TextView(activity);info.setTextColor(0xff62756a);info.setTextSize(14);
        info.setPadding(0,dp(6),0,dp(6));page.addView(info);
        rows=new LinearLayout(activity);rows.setOrientation(1);
        ScrollView scroll=new ScrollView(activity);scroll.addView(rows);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,dp(230)));
        LinearLayout actions=new LinearLayout(activity);
        actions.addView(button("Zmień nazwę",this::rename));actions.addView(button("Usuń",this::delete));page.addView(actions);
        LinearLayout folders=new LinearLayout(activity);
        folders.addView(button("Przenieś",this::move));folders.addView(button("Nowy folder",this::mkdir));page.addView(folders);
        ScrollView outer=new ScrollView(activity);outer.addView(page);
        dialog=new AlertDialog.Builder(activity).setTitle("Moje książki na Kindle").setView(outer).setNegativeButton("Zamknij",null).create();
        dialog.setOnDismissListener(d->onClose.run());dialog.show();load(path);
    }
    private void run(Task task,Done done) {
        if(working)return; working=true;info.setText("Łączę z Kindle…");dialog.setCancelable(false);dialog.getButton(-2).setEnabled(false);
        new Thread(()->{
            Session session=null;ChannelSftp channel=null;Object value=null;Exception error=null;
            try{session=connection.open();channel=(ChannelSftp)session.openChannel("sftp");channel.connect(12000);value=task.run(new RemoteFiles(channel,roots));}
            catch(Exception e){error=e;}
            finally{if(channel!=null)channel.disconnect();if(session!=null)session.disconnect();}
            final Object result=value;final Exception failure=error;
            activity.runOnUiThread(()->{
                working=false;dialog.setCancelable(true);dialog.getButton(-2).setEnabled(true);
                if(failure!=null){info.setText("Operacja niepotwierdzona: "+failure.getMessage());message("Nie udało się",failure.getMessage());}
                else done.accept(result);
            });
        },"kindle-files").start();
    }
    private void load(String target){run(f->f.list(target),r->{path=target;entries=(List<RemoteFiles.Entry>)r;selected.clear();search.setText("");render();});}
    private void render(){
        if(rows==null)return;rows.removeAllViews();location.setText(path.replace("/mnt/us/",""));
        String filter=search.getText().toString().toLowerCase(Locale.ROOT);int count=0;
        for(RemoteFiles.Entry e:entries){
            if(!e.name.toLowerCase(Locale.ROOT).contains(filter))continue;count++;
            if(e.directory)rows.addView(button("📁  "+e.name,()->load(e.path)));
            else {CheckBox check=new CheckBox(activity);check.setText("📖  "+e.name+"  ("+(e.size/1024)+" KB)");
                check.setTextSize(16);check.setTextColor(0xff20372d);
                check.setPadding(dp(6),dp(10),dp(4),dp(10));check.setChecked(selected.contains(e.path));
                check.setOnCheckedChangeListener((b,on)->{if(on)selected.add(e.path);else selected.remove(e.path);if(!working)info.setText("Zaznaczono: "+selected.size());});rows.addView(check);}
        }
        if(!working)info.setText("Książek w tym folderze: "+count+"  •  zaznaczono: "+selected.size());
    }
    private void message(String title,String text){new AlertDialog.Builder(activity).setTitle(title).setMessage(text).setPositiveButton("OK",null).show();}
    private void input(String title,String initial,String hint,java.util.function.Consumer<String> action){
        EditText edit=new EditText(activity);edit.setSingleLine(true);edit.setText(initial);edit.setSelectAllOnFocus(true);
        new AlertDialog.Builder(activity).setTitle(title).setMessage(hint).setView(edit).setNegativeButton("Anuluj",null)
            .setPositiveButton("Zapisz",(d,w)->action.accept(edit.getText().toString())).show();
    }
    private void rename(){
        if(selected.size()!=1){message("Zmiana nazwy","Zaznacz jedną książkę.");return;}
        String file=selected.iterator().next();String name=file.substring(file.lastIndexOf('/')+1);int dot=name.lastIndexOf('.');String ext=name.substring(dot);
        input("Zmień nazwę pliku",name.substring(0,dot),"Końcówka "+ext+" zostanie zachowana. Zamknij książkę w KOReaderze przed zmianą. Zmiana może wpłynąć na odnajdywanie jej zakładek i postępu czytania.",
            text->run(f->{f.rename(file,text+ext);return null;},r->load(path)));
    }
    private void mkdir(){input("Nowy folder","","Folder powstanie w "+path.replace("/mnt/us/",""),name->run(f->{f.mkdir(path,name);return null;},r->load(path)));}
    private void delete(){
        if(selected.isEmpty()){message("Usuwanie","Zaznacz książki do usunięcia.");return;}
        ArrayList<String> files=new ArrayList<>(selected);StringBuilder names=new StringBuilder();
        for(String file:files)names.append(file.substring(file.lastIndexOf('/')+1)).append('\n');
        new AlertDialog.Builder(activity).setTitle("Usunąć książki: "+files.size()+"?")
            .setMessage(names+"\nPliki zostaną trwale usunięte z Kindle. Kopie na telefonie pozostaną. Zamknij usuwane książki w KOReaderze.")
            .setNegativeButton("Anuluj",null).setPositiveButton("Usuń",(d,w)->batch(files,null)).show();
    }
    private void move(){
        if(selected.isEmpty()){message("Przenoszenie","Zaznacz książki do przeniesienia.");return;}
        ArrayList<String> files=new ArrayList<>(selected);
        new AlertDialog.Builder(activity).setTitle("Wybierz folder docelowy").setItems(new String[]{"documents","Books"},(d,w)->pickDestination(roots[w],files)).show();
    }
    private void pickDestination(String target,ArrayList<String> files){
        run(f->f.list(target),r->{
            ArrayList<String> names=new ArrayList<>();ArrayList<String> paths=new ArrayList<>();
            names.add("✓ Przenieś tutaj ("+files.size()+")");paths.add(target);
            if(!Arrays.asList(roots).contains(target)){names.add("↑ Folder wyżej");paths.add(target.substring(0,target.lastIndexOf('/')));}
            for(RemoteFiles.Entry e:(List<RemoteFiles.Entry>)r)if(e.directory){names.add("📁 "+e.name);paths.add(e.path);}
            new AlertDialog.Builder(activity).setTitle(target.replace("/mnt/us/",""))
                .setItems(names.toArray(new String[0]),(d,w)->{if(w==0)new AlertDialog.Builder(activity).setTitle("Przenieść książki?")
                    .setMessage("Do: "+target.replace("/mnt/us/","")+"\nZamknij te książki w KOReaderze. Ich zakładki i postęp mogą pozostać powiązane ze starym położeniem.")
                    .setNegativeButton("Anuluj",null).setPositiveButton("Przenieś",(q,x)->batch(files,target)).show();else pickDestination(paths.get(w),files);})
                .setNegativeButton("Anuluj",null).show();
        });
    }
    private void batch(ArrayList<String> files,String destination){
        run(f->{StringBuilder report=new StringBuilder();for(String file:files){try{if(destination==null)f.delete(file);else f.move(file,destination);report.append("✓ ");}
            catch(Exception e){report.append("✗ ").append(e.getMessage()).append(" — ");}report.append(file.substring(file.lastIndexOf('/')+1)).append('\n');}return report.toString();},
            r->{String report=(String)r;
                boolean allOk=!report.contains("✗");
                message(allOk ? "✓ Gotowe!" : "Nie wszystkie zmiany się udały",report);
                load(path);});
    }
}
